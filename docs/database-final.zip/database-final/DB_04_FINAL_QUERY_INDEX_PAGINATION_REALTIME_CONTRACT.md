# DB-04 — FINAL QUERY / INDEX / PAGINATION / REALTIME CONTRACT

**Status:** FROZEN. The authority for `firestore.indexes.json`.
**Global rules:** every list query carries `.limit()`; page size **25**; hard maximum **100**; cursor
pagination with `startAfter`, **never offset**; sorting is offered only on indexed fields — the UI
disables sorting elsewhere rather than sorting a partial page and lying; business lookup is a document
`get`, never a query; **no `collectionGroup` query exists anywhere in Release A or B.**

> **Security Rules are not filters.** A query is rejected unless the ruleset can permit its entire
> potential result set. Every query below is therefore scoped to a single tenant path, or is a public
> `get`, or executes server-side inside a callable with the Admin SDK. **No cross-tenant client list
> query exists.** Each row's *Permission assumption* states the rule that must admit it.

## 0. Cost model

`READS` is the billed document reads for one execution at the stated page size. Aggregation queries
(`count()`, `sum()`) bill one read per **1000 index entries** scanned, which is what keeps the dashboard
bounded. Denied reads are still billed, which is why the rules `get()` discipline matters.

Frozen budgets (`NFR-017`): **dashboard first render ≤ 12 reads**; **product list page ≤ 27 reads**.

---

## 1. Public and user-scoped

| Q | Caller | Path / collection | Tenant boundary | Filters | Order | Cursor | Page | Max | Index | Reads | RT | Empty | Permission assumption |
|---|---|---|---|---|---|---|---|---|---|---|:-:|---|---|
| Q-001 | 004, 007, 032, 005 | `organizationDirectory/{handle}` | public | doc `get` | – | – | 1 | 1 | none | 1 | – | not-found → `STATE-010`/`024` | `allow get: if true` · **`list` denied** |
| Q-002 | shell | `users/{uid}` | self | doc `get` | – | – | 1 | 1 | none | 1 | – | create on first render | `isSelf(uid)` |
| Q-003 | 003, 006, 008 | `users/{uid}/memberships` | self | `status == 'ACTIVE'` | `joinedAt ASC` | – | 25 | 25 | auto single-field | ≤ 25 | – | 0 → onboarding | `isSelf(uid)` |
| Q-004 | 026, 052 | `users/{uid}/notifications` | self | `read == false` \| none | `createdAt DESC` | ✔ | 25 (5 on 052) | 100 | `IDX-17` | ≤ 25 | – | "You're all caught up." | `isSelf(uid)` |
| Q-005 | 008, 026, 052 | `users/{uid}/notifications` | self | `read == false` | – | – | `count()` | – | `IDX-17` | 1 | **✔ RT-2** | 0 badge hidden | `isSelf(uid)` |

---

## 2. Organization, membership, settings

| Q | Caller | Collection | Filters | Order | Page | Index | Reads | RT | Permission assumption |
|---|---|---|---|---|---|---|---|:-:|---|
| Q-006 | 008, 028 | `organizations/{orgId}` doc `get` | – | – | 1 | none | 1 | – | `isActiveMember(orgId)` |
| Q-007 | 008, 028 | `…/settings/main` doc `get` | – | – | 1 | none | 1 | – | `isActiveMember(orgId)` |
| Q-008 | 008 | `…/members/{uid}` doc `get` | – | – | 1 | none | 1 | **✔ RT-1** | `isActiveMember(orgId)` |
| Q-009 | 027 | `…/members` | `status in [...]`, `role ==` | `joinedAt ASC` \| `displayName ASC` | 25 / 100 | `status, joinedAt` · `role, status, displayName` | ≤ 25 | – | `isActiveMember(orgId)` (read is member-wide; **actions** are Owner/Admin) |
| Q-010 | 027 | `…/invitations` | `status == 'PENDING'` | `expiresAt ASC` | 25 / 100 | `status, expiresAt` | ≤ 25 | – | **`hasRole(orgId, ['OWNER','ADMIN'])`** |

---

## 3. Inventory

| Q | Caller | Collection | Filters | Order | Page | Index | Reads | Empty |
|---|---|---|---|---|---|---|---|---|
| **Q-011** | 011 | **`productStockSummaries`** | `productStatus == 'ACTIVE'` | `productName ASC` | 25 / 100 | **IDX-33** | **25** | "Add your first product to start tracking inventory." |
| **Q-012** | 011 | `productStockSummaries` | `productStatus ==`, `categoryId ==` | `productName ASC` | 25 / 100 | **IDX-34** | 25 | "No products match these filters." |
| **Q-013** | 011 | `productStockSummaries` | `productStatus ==` | `productUpdatedAt DESC` | 25 / 100 | **IDX-35** | 25 | – |
| **Q-013b** | 011 | `productStockSummaries` | `productStatus ==`, `stockStatus ==` | `onHandMilli ASC` | 25 / 100 | **IDX-36** | 25 | – |
| Q-014 | 012, 013, 016, 042, **053** | `products/{id}` doc `get` | – | – | 1 | none | 1 | – |
| Q-015 | 011 | `productStockSummaries` | `productStatus ==` and (`internalSkuNormalized >= q, < q+` **or** `productName >= q, < q+`) | **the searched field ASC** | 25 | **IDX-30** / **IDX-33** | 25 | – |
| Q-016 | 012, 014 | `categories` | `status ==` | `name ASC` | 25 / 100 | `status, name` | ≤ 25 | – |
| Q-017 | 015, 016, 024, 042, **053** | `warehouses` | `status ==` | `name ASC` | 25 / 100 | `status, name` | ≤ 25 | – |
| Q-018 | 013, 016, 042, **053** | `stockBalances` | `productId ==` | `onHandMilli DESC` | 25 | **IDX-09** | ≤ 25 | "No stock recorded yet." |
| Q-019 | 048 | `stockBalances` | `warehouseId ==` | `onHandMilli DESC` | 25 / 100 | **IDX-08** | 25 | – |
| Q-020 | 011, 013 | `productStockSummaries/{productId}` doc `get` | – | – | 1 | none | 1 | – |
| Q-021 | 010 | `productStockSummaries` | `stockStatus == 'LOW_STOCK'` | `onHandMilli ASC` | 5 | **IDX-04** | 5 | "All tracked products are above their minimum level." |

**Search (`Q-015`) is a bounded prefix range on an indexed field, not full-text.** `FIELD-049` is scoped
to the list it sits in. Enterprise full-text search is explicitly excluded from scope; the UI must not
imply substring or fuzzy matching.

**Constraint that must reach the UI:** Firestore requires the first `orderBy` to be the field carrying
the range filter. **While a search term is active, the sort is forced to the searched field** (SKU or
name) and the other sort options are disabled — the same rule the frozen design already applies to
non-indexed columns. Sorting a partial result set and calling it "by on hand" would be a lie.

---

## 4. The stock ledger — the `TABLE-006` filter cube

`TABLE-006` permits any combination of `{ product?, warehouse?, Kind? }` plus a `createdAt` range, always
ordered `createdAt DESC`. A Firestore composite index is required per equality-set. Eight subsets, one of
which (`createdAt` alone) is served by a single-field index.

| Q | Filters | Index | Reads | Note |
|---|---|---|---|---|
| Q-022 | date range only | `IDX-07` `createdAt DESC` | 25 | also serves Recent Activity |
| Q-023 | `productId` | **IDX-05** | 25 | product detail recent movements uses `limit(5)` |
| Q-024 | `warehouseId` | **IDX-06** | 25 | |
| Q-025 | Kind | **IDX-20** `movementType, createdAt DESC` | 25 | *Correction* uses `in ['ADJUSTMENT_IN','ADJUSTMENT_OUT']` |
| Q-026 | `productId` + `warehouseId` | **IDX-21** | 25 | **closes a pre-existing gap** — `TABLE-006` always permitted this pair and `11` §8 declared no index for it |
| Q-027 | `productId` + Kind | **IDX-22** | 25 | |
| Q-028 | `warehouseId` + Kind | **IDX-23** | 25 | |
| Q-029 | `productId` + `warehouseId` + Kind | **IDX-24** | 25 | |
| Q-030 | `transferId ==` | auto single-field | **2** | fetches both halves of a transfer; `limit(2)`; used by tests and by the ledger's paired-row rendering |
| Q-063 | none | `IDX-07` | 5 | dashboard Recent Activity |

A `Kind` filter combined with an `in` of two values still uses the same composite index as an equality on
`movementType`; Firestore expands `in` into parallel index scans. `in` is capped at 30 values — we use 2.

---

## 5. Partners, procurement, reports

| Q | Caller | Collection | Filters | Order | Page | Index | Reads |
|---|---|---|---|---|---|---|---|
| Q-031 | 018, 019, 022 | `privatePartners` | `partnerTypes array-contains 'SUPPLIER'\|'BUYER'`, `status ==` | `name ASC` | 25 / 100 | **IDX-10** | 25 |
| Q-032 | 020 | `privatePartners/{id}` doc `get` | – | – | 1 | none | 1 |
| Q-033 | 010, 021 | `purchaseOrders` | `status in [...]` | `createdAt DESC` | 25 / 100 (5 on dashboard) | **IDX-11** | ≤ 25 |
| Q-034 | 021, 033 | `purchaseOrders` | `supplierKind ==`, `status in [...]` | `createdAt DESC` | 25 / 100 | **IDX-12** | 25 |
| Q-035 | 024 | `purchaseOrders` | `status in ['ORDERED','PARTIALLY_RECEIVED','SHIPPED']` | `expectedDate ASC` | 25 | **IDX-13** | ≤ 25 |
| Q-036 | 023, 024, 038, 039, 040 | `purchaseOrders/{poId}` doc `get` | – | – | 1 | none | 1 (**RT-3**) |
| Q-037 | as above | `…/{poId}/items` | – | `itemId ASC` | 50 | auto | ≤ 50 |
| Q-038 | as above | `…/{poId}/history` | – | `createdAt DESC` | 25 | auto | ≤ 25 |
| Q-039 | 020 | `purchaseOrders` | `privateSupplierId ==`, `status in [open]` | `createdAt DESC` | 10 | `privateSupplierId, status, createdAt DESC` | ≤ 10 |
| Q-040 | 020 | `purchaseOrders` | `privateSupplierId ==`, `status in [final]` | `createdAt DESC` | 10 | same | ≤ 10 |
| Q-061 | 048 | `stockBalances` (+ `Q-011a` join) | `warehouseId ==?`, `onHandMilli > 0` | `onHandMilli DESC` | 25 / 100 | **IDX-08/09** | 25 |
| Q-062 | 049 | `purchaseOrders` | `status in`, `supplierKind ==?`, `createdAt` range | `createdAt DESC` | 25 / 100 | **IDX-11/12** | 25 |

**CSV export exports the already-fetched, authorized page set only.** There is no unbounded export
query, and there is no mobile export at all (`CHG-044` / `MOBILE_REPORT_EXPORT = 0`).

---

## 6. Network (Release B-Lite) and aggregations

| Q | Caller | Collection | Filters | Order | Page | Index | Reads |
|---|---|---|---|---|---|---|---|
| Q-041 | 031, 036 | `…/connections` (projection) | `status in [...]` | `updatedAt DESC` | 25 / 100 | **IDX-14** | 25 |
| Q-042 | 020, 033 | `…/connections/{id}` doc `get` | – | – | 1 | none | 1 (**RT-4**) |
| Q-043 | 013, 033, 037, 038 | `…/productMappings` | `status ==`, `buyerProductId ==?` | `createdAt DESC` | 25 / 100 | **IDX-15** | ≤ 25 |
| Q-045 | 034, 051 | `…/partnerCatalog` (own org) | `published ==?` | `partnerSkuNormalized ASC` | 25 / 100 | **IDX-16** | 25 |
| **Q-046** | 035 | **callable `partnerCatalog.list`** | server: connection ACTIVE, then `published == true` | `partnerSkuNormalized ASC` | 25 / **100 hard** | **IDX-16** | server-side | 
| **Q-047** | 036 | **callable `partnerCatalog.lookupBySku`** | server: connection ACTIVE, `partnerSkuNormalized ==`, `published == true`, `limit(1)` | – | 1 | **IDX-16** | server-side |

`Q-046`/`Q-047` have **no client read path**. A rule on `organizations/{supplierOrgId}/partnerCatalog/**`
could not determine which of the caller's organizations is the buyer without a `get()` per candidate
organization — unbounded, and forbidden. Making the catalog callable-only costs one function and removes
an entire vulnerability class.

**Aggregation-backed KPIs** — `FR-DASH-008`. No dedicated aggregation index is needed; each reuses an
existing composite or single-field index.

| Q | KPI | Query | Index | Reads |
|---|---|---|---|---|
| Q-050 | Active SKUs | `count()` `products where status == 'ACTIVE'` | IDX-01 | 1 |
| Q-051 | Low stock | `count()` `productStockSummaries where stockStatus == 'LOW_STOCK'` | IDX-04 | 1 |
| Q-052 | Out of stock | `count()` … `== 'OUT_OF_STOCK'` | IDX-04 | 1 |
| Q-053 | Inventory value | `sum('stockValueMinor')` over `productStockSummaries` | single-field `stockValueMinor` | 1 |
| Q-054 | Open POs | `count()` `purchaseOrders where status in [ORDERED, SUBMITTED, ACCEPTED, SHIPPED, PARTIALLY_RECEIVED]` | IDX-11 | 1 |
| Q-055 | Awaiting receipt | `count()` `purchaseOrders where status in [SHIPPED, PARTIALLY_RECEIVED]` | IDX-11 | 1 |
| Q-060 | Inventory by location | `sum('onHandMilli')` per warehouse — **one aggregation per ACTIVE warehouse**, bounded by the warehouse count | IDX-08 | 1 per warehouse |
| Q-064 | Pending connections | `count()` `connections where status == 'PENDING'` | IDX-14 | 1 |
| Q-065 | Connected POs awaiting response | `count()` `purchaseOrders where supplierKind == 'CONNECTED' and status == 'SUBMITTED'` | IDX-12 | 1 |

**Dashboard first-render budget — stated precisely rather than optimistically.**

| Component | Reads |
|---|---|
| Shell — `Q-006`, `Q-007`, `Q-008` | 3, **cached by TanStack Query across navigations**, so 0 on a warm shell |
| KPI row — `Q-050`, `Q-051`, `Q-052`, `Q-053`, `Q-054`, `Q-055` | 6 aggregations |
| Needs Attention — `Q-021` (above the fold, so not deferrable) | 5 |
| **First meaningful render, warm shell** | **11** ✔ inside the ≤ 12 budget |
| Cold shell | 14 — over budget on the very first navigation of a session only |
| Deferred below the fold — `Q-063`, `Q-033`, `Q-060` | 5 + 5 + 1-per-warehouse |

This is an **obligation to measure at Stage 17**, not a claim already proven. `Q-060` is the one figure
that scales with warehouse count; beyond roughly ten warehouses it must move behind an interaction.
Recorded here rather than discovered on the day.

**Product-list budget — DB-CR-011, a correction found in the second adversarial pass.** The original
plan read 25 `products` and then joined 25 `productStockSummaries` by `documentId() in [...]`. That is
wrong: an `in` query still bills **one read per returned document**, so the page would cost **50 reads**
and breach the frozen `NFR-017` budget of 27. Batching does not reduce billing; it reduces round trips.

**Resolution: `TABLE-001` is served entirely from `productStockSummaries`.** The summary is already 1:1
with the product, is already written transactionally by the stock commands, and now carries the
denormalised display fields (DB-02 §4.5): `productName`, `internalSku`, `internalSkuNormalized`,
`categoryId`, `categoryName`, `productStatus`, `baseUnitPriceMinor`, `preferredSupplierName`,
`productUpdatedAt`. The product list therefore costs exactly **25 reads**, from one collection, with one
index per sort — inside budget with room to spare.

`products` remains canonical. `product.create` and `product.update` write the summary's denormalised
fields **in the same transaction** (they already write it for `stockValueMinor`), so `DV-10` holds by
construction and no new drift class is introduced.

**Warehouse filter on the product list** is the one filter that cannot be served from the summary,
because "products held in warehouse W" lives in `stockBalances`. It is a two-step read: `Q-019`
(`stockBalances where warehouseId == W and onHandMilli > 0`, 25 rows) then the matching summaries by id.
It is bounded to one page and is the only two-step list in the system.

---

## 7. Complete index set — the authority for `firestore.indexes.json`

Single-field indexes Firestore creates automatically are not listed. All indexes are deployed **before**
the application (`11` §28).

| # | Collection | Fields | Serves |
|---|---|---|---|
| IDX-01 | `products` | `status ASC, name ASC` | active-SKU `count()`; PO-builder product picker |
| IDX-02 | `products` | `status ASC, categoryId ASC, name ASC` | PO-builder picker, category-scoped |
| IDX-03 | `products` | `status ASC, updatedAt DESC` | retained for admin/product-side listing |
| IDX-04 | `productStockSummaries` | `stockStatus ASC, onHandMilli ASC` | low-stock list and `count()` |
| IDX-05 | `stockMovements` | `productId ASC, createdAt DESC` | product movement history |
| IDX-06 | `stockMovements` | `warehouseId ASC, createdAt DESC` | warehouse movement history |
| IDX-07 | `stockMovements` | `createdAt DESC` | org-wide ledger and Recent Activity |
| IDX-08 | `stockBalances` | `warehouseId ASC, onHandMilli DESC` | warehouse archive guard; inventory by location |
| IDX-09 | `stockBalances` | `productId ASC, onHandMilli DESC` | product-detail per-warehouse table |
| IDX-10 | `privatePartners` | `partnerTypes ARRAY, status ASC, name ASC` | supplier / buyer tabs |
| IDX-11 | `purchaseOrders` | `status ASC, createdAt DESC` | PO list; open-PO `count()` |
| IDX-12 | `purchaseOrders` | `supplierKind ASC, status ASC, createdAt DESC` | private vs connected tabs |
| IDX-13 | `purchaseOrders` | `status ASC, expectedDate ASC` | awaiting-receipt panel |
| IDX-14 | `connections` (projection) | `status ASC, updatedAt DESC` | connections list |
| IDX-15 | `productMappings` | `status ASC, buyerProductId ASC` | mappings list; product-detail mappings |
| IDX-16 | `partnerCatalog` | `published ASC, partnerSkuNormalized ASC` | supplier catalog; buyer SKU lookup |
| IDX-17 | `notifications` | `read ASC, createdAt DESC` | notification list and unread `count()` |
| IDX-18 | `auditLogs` | `entityType ASC, entityId ASC, createdAt DESC` | per-object Activity tab |
| IDX-19 | `auditLogs` | `createdAt DESC` | org audit stream |
| **IDX-20** | `stockMovements` | `movementType ASC, createdAt DESC` | **A1** — Kind filter |
| **IDX-21** | `stockMovements` | `productId ASC, warehouseId ASC, createdAt DESC` | **gap closure** — product + warehouse filter |
| **IDX-22** | `stockMovements` | `productId ASC, movementType ASC, createdAt DESC` | **A1** |
| **IDX-23** | `stockMovements` | `warehouseId ASC, movementType ASC, createdAt DESC` | **A1** |
| **IDX-24** | `stockMovements` | `productId ASC, warehouseId ASC, movementType ASC, createdAt DESC` | **A1** |
| IDX-25 | `members` | `status ASC, role ASC` | notification recipient resolution `limit(50)` |
| IDX-26 | `purchaseOrders` | `privateSupplierId ASC, status ASC, createdAt DESC` | partner open POs / order history |
| IDX-27 | `invitations` | `status ASC, expiresAt ASC` | pending invitations |
| IDX-28 | `categories` | `status ASC, name ASC` | category list |
| IDX-29 | `warehouses` | `status ASC, name ASC` | warehouse list |
| IDX-30 | `products` | `status ASC, internalSkuNormalized ASC` | PO-builder SKU picker |
| IDX-31 | `members` | `status ASC, joinedAt ASC` | team list |
| **IDX-33** | `productStockSummaries` | `productStatus ASC, productName ASC` | **DB-CR-011** — default product list; SKU/name prefix search |
| **IDX-34** | `productStockSummaries` | `productStatus ASC, categoryId ASC, productName ASC` | **DB-CR-011** — category filter |
| **IDX-35** | `productStockSummaries` | `productStatus ASC, productUpdatedAt DESC` | **DB-CR-011** — "recently updated" sort |
| **IDX-36** | `productStockSummaries` | `productStatus ASC, stockStatus ASC, onHandMilli ASC` | **DB-CR-011** — stock-status filter on the list |
| **IDX-37** | `productStockSummaries` | `productStatus ASC, internalSkuNormalized ASC` | **DB-CR-011** — SKU prefix search |
| **IDX-38** | `products` | `categoryId ASC, status ASC` | **DB-CR-012** — `category.archive` guard (`Q-072`) |

`INDEX_COVERAGE`: every query in §1–§6 resolves to a row above or to an automatic single-field index.
**No collection-group index is required** — the `users/{uid}/memberships` mirror removed the only need
for one.

---

## 8. Command-internal queries

These execute with the Admin SDK **inside** a transaction. Every one is bounded, and none reads a
document belonging to a third organization.

| Q | Command | Query | Bound |
|---|---|---|---|
| Q-056 | `warehouse.archive` | `stockBalances where warehouseId == W and onHandMilli > 0` | **`limit(1)`** — a guard, not a report |
| Q-057 | `warehouse.archive` | `purchaseOrders where status in [ORDERED, PARTIALLY_RECEIVED, ACCEPTED, SHIPPED] and receivingWarehouseId == W` | **`limit(1)`** |
| Q-058 | `015` UI, **outside** the transaction | `count()` + `sum('onHandMilli')` on `stockBalances where warehouseId == W and onHandMilli > 0` | for the *message detail* only — *"Cold Room holds 6 products worth LKR 398,900.00"*. Aggregations are unavailable inside a transaction, so the **guard** is `Q-056`/`Q-057` and this is display-only |
| Q-059 | `notify()` | `members where status == 'ACTIVE' and role in [...]` | **`limit(50)`**; resolved **before any write**; exceeding 50 skips the notification and logs a warning rather than blowing the transaction budget |
| Q-066 | `product.create/update` | `productSkuIndex/{skuNorm}` `txn.create` | precondition, not a query |
| Q-067 | `org.create` | `handleReservations/{handle}` `txn.create` | precondition |
| Q-068 | `po.order`, `cpo.submit` | `counters/purchaseOrder` doc read | 1 |
| Q-069 | every idempotent command | `commandReceipts/{operationId}` doc read | 1 — **the first read** |
| Q-070 | `mapping.create` | `productMappings where buyerProductId == P and supplierCatalogItemId == C and status == 'VERIFIED'` | **`limit(1)`**; index `buyerProductId, supplierCatalogItemId, status` (**IDX-32**) |
| **Q-071** | **`stock.transfer`** | `stockBalances/{P}__{FROM}` and `stockBalances/{P}__{TO}` doc reads | **2, by deterministic id — no query, no scan** |
| **Q-072** | **`category.archive`** *(DB-CR-012)* | `products where categoryId == C and status == 'ACTIVE'` | **`limit(1)`** — index **IDX-38**; a guard, not a report |
| **Q-073** | **`warehouse.setDefault`** *(DB-CR-013)* | `settings/main` doc read | 1 |

`IDX-32` `productMappings` `buyerProductId ASC, supplierCatalogItemId ASC, status ASC` is added for
`Q-070`; `11` §8 declared no index for the duplicate-mapping guard.

---

## 9. Contract result

```
QUERY_COVERAGE   = 100%   (74 query ids; every UI read and every command-internal read has one)
INDEX_COVERAGE   = 100%   (38 composite indexes + automatic single-field)
PAGINATION       = cursor only, 25 / 100, on every list without exception
REALTIME         = 4 listeners, all bounded, all justified (DB-03 §5)
COLLECTION_GROUP = 0
CROSS_TENANT_CLIENT_QUERIES = 0
RULES_QUERY_COMPATIBILITY   = every client query is single-tenant-path scoped
```
