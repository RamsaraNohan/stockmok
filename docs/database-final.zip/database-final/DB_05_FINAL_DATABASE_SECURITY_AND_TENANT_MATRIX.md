# DB-05 — FINAL DATABASE SECURITY AND TENANT MATRIX

**Status:** FROZEN. The architectural authority for `firestore.rules` and for the authorization block of
every backend command.
**Role registry:** the seven roles of `06` §5, verbatim. No role may be added, removed or merged.

```
Role = OWNER | ADMIN | INVENTORY_MANAGER | PROCUREMENT_MANAGER | STOREKEEPER | ANALYST | VIEWER
```

## 0. Operation vocabulary

`READ` · `CREATE` · `UPDATE` · `ARCHIVE` (a guarded status transition, never a delete) ·
`COMMAND_ONLY` (mutation exists but only through a trusted backend command) · `DENY`.

**`DELETE` is absent from this vocabulary for clients.** Client deletes are denied on every collection,
everywhere, without exception (`INV-21`, `SEC-019`, `T-SEC-19`).

## 0.1 Principals

`PUB` unauthenticated visitor · `AUTH` authenticated non-member · `O` `A` `IM` `PM` `SK` `AN` `V` ACTIVE
members · `SUSP` suspended or removed member · `CONN` a member of a **connected counterparty**
organization · `BE` trusted backend (Admin SDK).

> **`SUSP` is denied everywhere, at both layers.** `isActiveMember()` requires `status == 'ACTIVE'`, and
> every command re-reads the membership at request time. A cached tab or a live ID token grants nothing.
> The shell additionally holds an `onSnapshot` on the member document (RT-1) so the UI collapses without
> a refresh — but that is convenience; the denial is structural.

> **`CONN` has no rule-level privilege anywhere.** A connected counterparty is, to Firestore Security
> Rules, an ordinary non-member. Every legitimate cross-tenant read happens inside a callable that
> verifies `connections/{buyerOrgId}__{supplierOrgId}.status == 'ACTIVE'` server-side. This is why the
> matrix below shows `CONN = DENY` on every tenant path including `partnerCatalog`.

## 0.2 Role constants (mirrored into `firestore.rules` by necessity)

```text
INVENTORY_WRITERS = ['OWNER','ADMIN','INVENTORY_MANAGER']
PARTNER_WRITERS   = ['OWNER','ADMIN','PROCUREMENT_MANAGER']
PO_WRITERS        = ['OWNER','ADMIN','PROCUREMENT_MANAGER']
RECEIVERS         = ['OWNER','ADMIN','INVENTORY_MANAGER','PROCUREMENT_MANAGER','STOREKEEPER']
TRANSFER_WRITERS  = INVENTORY_WRITERS                                            # A1
ADMINS            = ['OWNER','ADMIN']
```

Rules cannot import TypeScript, so these lists are duplicated from `packages/shared/permissions.ts`.
**`T-SEC-17` asserts the two agree for every role.** That test is the mitigation, and it is not optional.

---

## 1. The path-constancy rule

> A Security Rule may only `get()` or `exists()` a path that is **constant for the entire request** —
> in practice `organizations/{orgId}/members/{request.auth.uid}`, where `orgId` comes from the matched
> path. **A rule must never read a path derived from `resource.data`.**

Firestore permits at most **10** document access calls per single-document or query request (**20** for
multi-document reads, transactions and batched writes), and identical calls are cached. A constant-path
read costs one cached call regardless of page size; a data-derived read costs one call per candidate
document and fails a 25-row page outright.

Every cross-tenant authorization question in Stockmok requires exactly the forbidden read, because a
user may belong to several organizations and a rule cannot know which one they are acting for. **That is
why zone 4 is closed to clients and the partner catalog is callable-only.** It is the reason the
architecture has this shape.

---

## 2. Zone 1 — public

| Path | PUB | AUTH | O A IM PM SK AN V | CONN | SUSP | BE |
|---|---|---|---|---|---|---|
| `organizationDirectory/{handle}` | **READ (`get` only)** | READ `get` | READ `get` | READ `get` | READ `get` | CREATE/UPDATE |
| `organizationDirectory` **`list`** | **DENY** | **DENY** | **DENY** | **DENY** | **DENY** | n/a |
| `storefrontCatalog/**` | *(Release C — not built; rule present and inert)* | | | | | |

`get` public / `list` denied is the whole anti-enumeration control. Exact-handle lookup needs only
`get`; permitting `list` would let any visitor dump every business on the platform (`T-SEC-20`).
Exposing `organizationId` publicly is a deliberate accepted decision — the id is not a secret,
membership is the gate, and branded login needs it.

---

## 3. Zone 2 — user-private

| Path | Self | Any other principal | BE |
|---|---|---|---|
| `users/{uid}` | READ · CREATE · UPDATE **(`displayName`, `photoUrl`, `lastSeenAt` only)** | **DENY** | UPDATE (`email`, `status`) |
| `users/{uid}/memberships/{orgId}` | READ | **DENY** | CREATE/UPDATE |
| `users/{uid}/notifications/{id}` | READ · UPDATE **(`read` only)** | **DENY** | CREATE |

A notification update touching any field other than `read` is denied (`T-SEC-23`). `create` and `delete`
on notifications are denied to the recipient — a user cannot fabricate their own notification.

---

## 4. Zone 3 — organization-private

`READ` below means `isActiveMember(orgId)` unless a narrower role list is given. Every cell for a
principal outside the organization — `PUB`, `AUTH`, `CONN`, `SUSP` — is **`DENY`**, at every path,
without exception. That row is not repeated per path; it is the catch-all plus `isActiveMember()`.

| Path | READ | CREATE | UPDATE | ARCHIVE | Mutation class |
|---|---|---|---|---|---|
| `organizations/{orgId}` | all 7 | DENY | DENY | – | COMMAND_ONLY |
| `…/settings/main` | all 7 | DENY | DENY | – | COMMAND_ONLY (`ADMINS`) |
| `…/counters/**` | **DENY** | DENY | DENY | – | **BACKEND_ONLY** |
| `…/commandReceipts/**` | **DENY** | DENY | DENY | – | **BACKEND_ONLY** |
| `…/productSkuIndex/**` | **DENY** | DENY | DENY | – | **BACKEND_ONLY** |
| `…/members/{uid}` | all 7 | DENY | DENY | – | COMMAND_ONLY (`ADMINS`) |
| `…/invitations/**` | **`ADMINS` only** | DENY | DENY | – | COMMAND_ONLY (`ADMINS`) |
| `…/categories/**` | all 7 | **`INVENTORY_WRITERS`** | **`INVENTORY_WRITERS`**, **`status` may not change** | **COMMAND_ONLY** (DB-CR-012) | mixed |
| `…/warehouses/**` | all 7 | **`INVENTORY_WRITERS`** | **`INVENTORY_WRITERS`**, **`status` may not change**; no `isDefault` field exists | **COMMAND_ONLY** | mixed |
| `…/products/**` | all 7 | DENY | DENY | COMMAND_ONLY | COMMAND_ONLY (`INVENTORY_WRITERS`) |
| `…/stockBalances/**` | all 7 | **DENY** | **DENY** | – | COMMAND_ONLY |
| `…/productStockSummaries/**` | all 7 | **DENY** | **DENY** | – | COMMAND_ONLY |
| `…/stockMovements/**` | all 7 **except V** at UI level; rules allow all members | **DENY** | **DENY (immutable)** | **DENY** | COMMAND_ONLY |
| `…/privatePartners/**` | all 7 | **`PARTNER_WRITERS`** | **`PARTNER_WRITERS`** (incl. deactivate) | via `status` (client) | **SAFE_DIRECT_CLIENT_WRITE** |
| `…/purchaseOrders/{poId}` | all 7 | **`PO_WRITERS`** and `isNewPrivateDraft()` | **`PO_WRITERS`** and `isEditableDraft()` and `draftFieldsOnly()` | – | mixed |
| `…/purchaseOrders/{poId}/items/**` | all 7 | `PO_WRITERS` + `parentIsEditableDraft()` | same | – | mixed |
| `…/purchaseOrders/{poId}/history/**` | all 7 | **DENY** | **DENY (immutable)** | – | COMMAND_ONLY |
| `…/partnerCatalog/**` | **own org members only** | DENY | DENY | – | COMMAND_ONLY (`PARTNER_WRITERS`) |
| `…/productMappings/**` | all 7 | DENY | DENY | – | COMMAND_ONLY (`PARTNER_WRITERS`) |
| `…/connections/**` (projection) | all 7 | DENY | DENY | – | COMMAND_ONLY |
| `…/auditLogs/**` | **`ADMINS` only** | **DENY** | **DENY** | **DENY** | COMMAND_ONLY |

**Rules-level read is deliberately coarser than the UI.** `stockMovements` is readable by every ACTIVE
member at the rules layer while `23` denies Viewer the Movement History **screen**. This is intentional
and stated: expressing a per-role read denial on a list would require the rule to be a filter, which it
is not. The screen-level denial is enforced by the route guard and by `SCREEN-029` rendering with **no
page query executed**. Where a read genuinely must be restricted — invitations and audit logs — it is
enforced in rules by `hasRole(orgId, ADMINS)`, because those are the two collections whose exposure
would be a real leak.

### 4.1 `isEditableDraft()` — the exact predicate

```text
isNewPrivateDraft()   request.resource.data.supplierKind == 'PRIVATE'
                   && request.resource.data.status == 'DRAFT'
                   && request.resource.data.isProjection == false

isEditableDraft()     resource.data.supplierKind == 'PRIVATE'
                   && resource.data.status == 'DRAFT'
                   && request.resource.data.supplierKind == 'PRIVATE'     // cannot be flipped
                   && request.resource.data.status == 'DRAFT'             // cannot self-transition

draftFieldsOnly()     onlyChanged(['counterpartyName','privateSupplierId','expectedDate',
                                   'notes','totalMinor','updatedAt'])
```

`supplierKind` and `status` are pinned on **both** `resource` and `request.resource`, so a client cannot
flip a private draft to `CONNECTED`, cannot self-transition `DRAFT → ORDERED`, and cannot edit a
connected draft (which is `COMMAND_ONLY` via `cpo.draftSave` — DB-CR-010).

---

## 5. Zone 4 — cross-tenant canonical

| Path | PUB | AUTH | any member of either party | CONN | BE |
|---|---|---|---|---|---|
| `handleReservations/{handle}` | DENY | DENY | **DENY** | DENY | full |
| `connections/{connectionId}` | DENY | DENY | **DENY** | DENY | full |
| `connectedPurchaseOrders/{poId}` and all subcollections | DENY | DENY | **DENY** | DENY | full |

`allow read, write: if false;` — for **every** principal including the Owner of a participating
organization. Each party reads its own zone-3 projection with the ordinary `isActiveMember(orgId)` rule:
no special case, no data-derived read. A third organization has no projection and cannot read the
canonical record, so it sees nothing (`T-SEC-12`).

---

## 6. Catch-all

```text
match /{document=**} { allow read, write: if false; }
```

An invented path is denied (`T-SEC-18`). This is the last line of the ruleset and is asserted by test.

---

## 7. Backend command authorization

**The Admin SDK bypasses Firestore Security Rules completely. A Cloud Function is not protected by
`firestore.rules`.** Steps 1–7 below are therefore the *only* authorization that exists for a command,
and they are implemented **once**, in `defineCommand()`.

| # | Check | Failure |
|---|---|---|
| 1 | `AUTH` — `context.auth.uid` present | `unauthenticated` |
| 2 | `INPUT` — Zod schema, the same object the browser form used | `invalid-argument` + field path |
| 3 | `MEMBERSHIP` — read `organizations/{orgId}/members/{uid}` **from the database** | `permission-denied / NOT_A_MEMBER` |
| 4 | `STATE` of membership — must be `ACTIVE` | `permission-denied / MEMBERSHIP_NOT_ACTIVE` |
| 5 | `ROLE` — the role **on that document**, never `request.data.role` | `permission-denied / ROLE_NOT_PERMITTED` |
| 6 | `ORGANIZATION` — every referenced resource re-read and its `organizationId` compared to the verified membership | `permission-denied / CROSS_TENANT_REFERENCE` |
| 7 | `STATE` of resource — the transition table in DB-07 | `failed-precondition / INVALID_TRANSITION` |
| 8 | `IDEMPOTENCY` — receipt read as the **first** read inside the transaction | replay → stored result; hash mismatch → `failed-precondition / OPERATION_REPLAYED_WITH_DIFFERENT_PAYLOAD` |
| 9 | `PRIVACY` — the result and any projection carry allow-listed fields only | – |

**`request.data.orgId` is a routing hint, never a claim.** Step 3 turns it into a fact or a denial. If
removing a field from the payload would change an authorization decision, that field is being trusted
and the design is wrong.

### 7.1 Command → role gate (complete)

| Roles | Commands |
|---|---|
| any authenticated user, no membership | `org.create` |
| self | `user.bootstrapProfile` *(optional)* |
| `ADMINS` | `org.updateSettings`, `team.createInvitation`, `team.revokeInvitation`, `team.changeMemberRole`, `team.setMemberStatus`, `connection.disable`, `storefront.*` (C) |
| authenticated invitee (email-matched) | `team.acceptInvitation` |
| `INVENTORY_WRITERS` | `product.create`, `product.update`, `product.setStatus`, `warehouse.archive`, **`warehouse.setDefault`**, **`category.archive` / `category.restore`**, `stock.recordOpeningBalance`, `stock.adjust`, **`stock.transfer`** |
| `RECEIVERS` | `po.receive`, `cpo.receive` |
| `PO_WRITERS` | `po.order`, `po.cancel`, `cpo.draftSave`, `cpo.submit`, `cpo.respond`, `cpo.ship`, `cpo.cancel` |
| `PARTNER_WRITERS` | `connection.request`, `connection.respond`, `partnerCatalog.publish`, `partnerCatalog.unpublish`, `partnerCatalog.list`, `partnerCatalog.lookupBySku`, `mapping.create`, `mapping.disable` |

**Storekeeper receives goods but cannot adjust or transfer stock.** Receiving is a documented, referenced
event against a purchase order; a free-form adjustment or relocation is not. Separating them is the
standard segregation-of-duties control (`06` §5) and A1 extends it to transfer, which sits in the same
family on frozen board 6i.

**Inventory Manager has no Network access.** Connections are commercial relationships; procurement owns
them. **Analyst** is read-only everywhere except audit logs and team, and has no Network access.
**Viewer** sees the dashboard, products, stock and the Stock-on-Hand report only.

### 7.2 Cross-organization commands

`connection.*` and `cpo.*` legitimately touch two tenants. Each verifies:

1. the caller's ACTIVE membership and role **in the organization they claim to act for**;
2. that the canonical `connections/{buyerOrgId}__{supplierOrgId}` document names that organization in the
   correct role — **buyer transitions require `buyerOrgId`, supplier transitions require `supplierOrgId`**;
3. connection `status == 'ACTIVE'` **re-read inside the transaction**, so a connection disabled between
   page load and submit is rejected (`ATTACK-09`);
4. that every write targets only the two participating organizations, each receiving only fields it is
   entitled to see.

**`stock.transfer` is not a cross-organization command and must never become one.** Both warehouses are
re-read from `organizations/{orgId}/warehouses/**` under the verified membership, so a warehouse id
belonging to another organization resolves to a missing document, not to another tenant's data
(`T-SEC-25`).

---

## 8. Privacy boundaries

| Boundary | Rule |
|---|---|
| **Public directory** | Exactly nine fields (DB-02 §1.1). `list` denied. Key set asserted by `T-SEC-16`. |
| **Partner catalog** | Allow-listed projection document. Buyer access **only** via `partnerCatalog.list` / `lookupBySku`, each verifying an ACTIVE connection server-side. No direct client read path exists. |
| **Never crosses to a connected buyer** | supplier Products · StockBalances · ProductStockSummaries · StockMovements · AuditLogs · Members · PrivatePartners · Settings · Invitations · Counters · exact stock quantity · internal cost · margin · warehouse identity. `T-SEC-10` asserts denial on each **for a connected buyer**, not merely for an unrelated organization — a connected party is the more interesting attacker. |
| **Shared purchase order** | The canonical record carries only fields both parties are entitled to see. Buyer-private context — internal notes, private cost, unrelated tenant data — is never copied into it. A buyer's connected **draft** exists only in the buyer's tenant until submission. |
| **Audit** | Owner/Admin read only; create/update/delete denied to every client including the Owner. A cross-tenant action writes one record per organization, each scoped to what that organization may know. |
| **Whole-document reads** | Firestore reads whole documents, so a rule cannot hide a field. That is precisely why every public and partner surface is a separate projection document rather than a filtered view. |
| **Transfer** | Strictly intra-organization. Reads and writes only under the caller's own `organizations/{orgId}/`. Carries no counterparty field and can never appear in any projection. |

---

## 9. Rules-testing contract

`tests/rules/` uses `@firebase/rules-unit-testing` with `initializeTestEnvironment`, seeding fixtures
with `withSecurityRulesDisabled`. Fixtures: two organizations (`org-grand-ocean`, `org-fresh-foods`), one
ACTIVE connection, **seven** users covering every role, one suspended member, one authenticated
non-member and one unauthenticated context.

Assertion groups — approximately 55, all P0:

1. Unauthenticated read of every private collection → denied.
2. Authenticated non-member read of every tenant collection → denied.
3. Cross-tenant read **and** write for products, balances, summaries, movements, members, audit, POs,
   mappings, catalog → denied.
4. Direct writes to `stockBalances`, `stockMovements`, `productStockSummaries`, `products`, `members`,
   `auditLogs`, `commandReceipts`, `counters`, `productSkuIndex` → denied **for every role including
   Owner**.
5. `auditLogs` `update` and `delete` by Owner → denied.
6. Suspended member → denied on every path.
7. For each of the six client-writable surfaces: every permitted role succeeds, every other role fails.
8. Warehouse update setting `status` → denied; **category update setting `status` → denied** (DB-CR-012); a client attempting to set a default warehouse on the warehouse document → denied (no such field).
9. PO update when `status != 'DRAFT'` → denied; when `supplierKind == 'CONNECTED'` → denied; flipping
   `supplierKind` → denied; self-transitioning `status` → denied.
10. `organizationDirectory` `get` allowed unauthenticated; **`list` denied**.
11. Every zone-4 collection → denied for all seven roles in **both** organizations.
12. An invented path → denied by the catch-all.
13. Notification update touching any field other than `read` → denied; `create` by self → denied.
14. **A `CONN` member reading the counterparty's `partnerCatalog` directly → denied** (the callable is
    the only path).
15. Client `delete` on every collection → denied.
16. `T-SEC-17`: the role lists in `firestore.rules` equal the shared permission table, per role.
17. **`T-SEC-24`** *(A1)*: `SK`, `PM`, `AN`, `V` calling `stock.transfer` → denied.
18. **`T-SEC-25`** *(A1)*: a transfer naming a warehouse in another organization → denied at step 6.

---

## 10. Matrix result

```
RBAC_COVERAGE          = 100%   (7 roles × every path and every command)
TENANT_ISOLATION       = enforced structurally by path prefix + constant-path membership read
CONNECTED_PRIVACY      = enforced by projection documents + connection-verified callables
CLIENT_WRITE_SURFACES  = 6      (and no more)
CLIENT_DELETE_PATHS    = 0
ZONE_4_CLIENT_ACCESS   = 0
DATA_DERIVED_RULE_READS= 0
```
