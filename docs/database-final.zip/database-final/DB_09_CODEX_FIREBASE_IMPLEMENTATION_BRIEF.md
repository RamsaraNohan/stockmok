# DB-09 — CODEX FIREBASE / DATA-FOUNDATION IMPLEMENTATION BRIEF

**Audience:** Codex, acting as the deterministic data-platform implementer.
**Authority:** this brief plus DB-00 → DB-08. Where they disagree, DB-00 → DB-08 win.
**Rule above all others:** *if a decision is not written down, stop and ask. Do not choose.*

---

## 1. READ FIRST — in this order, before writing any file

1. `docs/database-final/DB_00_AUTHORITY_AMENDMENT_A1_TRANSFER.md` — what changed and why
2. `DB_02_FINAL_FIRESTORE_PHYSICAL_SCHEMA.md` — every document and field you will type
3. `DB_04_FINAL_QUERY_INDEX_PAGINATION_REALTIME_CONTRACT.md` — the authority for `firestore.indexes.json`
4. `DB_06_FINAL_COMMAND_TRANSACTION_CONTRACT.md` — command signatures you will generate types for
5. `DB_07_FINAL_STATE_MACHINE_AND_INVARIANT_CONTRACT.md` — the transition tables you will encode
6. `DB_08_FINAL_SEED_MIGRATION_AND_DATABASE_TEST_PLAN.md` — the seed you will build
7. `DB_05_FINAL_DATABASE_SECURITY_AND_TENANT_MATRIX.md` — **read for context; you do not implement it**
8. `Stockmok_Final_Control_Pack_v4/11_FINAL_FIREBASE_IMPLEMENTATION_ARCHITECTURE.md` §1–3, §27–29
9. `FIREBASE_PROJECT_FACTS.md` — the provisioned truth

---

## 2. YOU OWN

| Area | Deliverable |
|---|---|
| Firebase config | `.firebaserc`, `firebase.json` (hosting, firestore, functions, emulators), `.env.example` |
| Emulator Suite | auth 9099 · firestore 8080 · functions 5001 · hosting 5000 · UI 4000 · `singleProjectMode: true` · `.emulator-data/` git-ignored |
| Indexes | `firestore.indexes.json` — **exactly IDX-01 … IDX-38 from DB-04 §7**, no more, no fewer |
| Shared types | `src/shared/types/` — every enum and document interface from DB-02, with branded `Milli` and `Minor` types |
| Schemas | `src/shared/schemas/` — one Zod schema per document and per command payload; the **same** object validates the browser form and re-validates inside the function |
| Converters | typed `FirestoreDataConverter` per collection; typed collection-reference helpers so a path string appears **once** in the codebase |
| Path contract | `src/shared/contracts/paths.ts` — every path from DB-01 §4 as a typed builder; **no string concatenation of paths anywhere else** |
| Domain utilities | money/milli arithmetic with half-up rounding, `deriveStockStatus`, unit conversion, handle normalisation + reserved-word list, SKU normalisation, payload hashing — all pure, all unit-tested at the boundary |
| Transition tables | DB-07 §1–§9 as data, plus `canTransition()`; **table only — no command bodies** |
| Seed and reset | `scripts/seed.ts`, `scripts/reset.ts` per DB-08 §5, writing **through the command layer** |
| Fixtures and factories | `tests/factories/**` per DB-08 §8 |
| Query/data test infrastructure | rules-test harness, emulator bootstrap, the property-test generator skeleton, CI wiring |
| Repository scaffolding | `src/data/**` read-side query functions with the Q-ids from DB-04 as their names |

---

## 3. YOU MAY CREATE

`firebase.json` · `.firebaserc` · `firestore.indexes.json` · `functions/` scaffold (config, tsconfig,
`index.ts` that re-exports **only**; **no command bodies**) · `packages/shared/**` · `src/shared/**` ·
`src/data/**` · `scripts/**` · `tests/factories/**` · `tests/setup/**` · CI workflow · `README` sections
covering emulator start, seed and verify.

## 4. YOU MUST NOT TOUCH

- **`firestore.rules`** — Claude Code owns it. Not a stub, not a placeholder, not "just the helpers".
- **Any command body** in `functions/src/commands/**`, and **`defineCommand()`**, `idempotency.ts`,
  `audit.ts`, `notify.ts` — Claude Code owns every one.
- Any file under `docs/final/`, `docs/ui-final/`, `docs/audit-final/`, `Stockmok_Final_Control_Pack_v4/`,
  or `visual-designs/`.
- The React application, screens, routing or design tokens.
- `FIREBASE_PROJECT_FACTS.md`.

## 5. FROZEN DECISIONS — do not revisit, do not "improve"

| | |
|---|---|
| Roles | **seven**, exactly: `OWNER, ADMIN, INVENTORY_MANAGER, PROCUREMENT_MANAGER, STOREKEEPER, ANALYST, VIEWER` |
| Zones | four; `handleReservations`, `connections`, `connectedPurchaseOrders` are **closed to clients** |
| Paths | DB-01 §4 verbatim; no family may move, be added or be removed |
| Quantities | integer **milli**-units, 3 dp max, `unit` always stored alongside |
| Money | integer **minor** units, explicit `currency`, half-up rounding, **no floats, ever** |
| Deterministic ids | `{buyerOrgId}__{supplierOrgId}` · `{productId}__{warehouseId}` · `{productId}` · normalised SKU · normalised handle · `operationId` |
| Handle | lowercase `[a-z0-9-]`, **3–30**, reserved-word list enforced |
| Pagination | cursor `startAfter`, page 25, hard max 100, **never offset** |
| Sorting | indexed fields only |
| Deletes | **denied everywhere**; archive or deactivate instead |
| Stock truth | the ledger; balances and summaries are transactional derivations |
| Transfer | **one product**, same organization, different warehouses, positive quantity, paired movements, summary untouched |
| `movementKind` | **derived, never persisted** — DB-02 §0.2 |
| Realtime | exactly the four listeners in DB-03 §5 |
| Endpoints | callables only — **zero HTTP, zero Firestore triggers** |
| Runtime | Cloud Functions **2nd gen, Node 22** (Node 20 is deprecated), region **`asia-southeast1`** |

## 6. IMPLEMENT

1. Repository scaffold, TypeScript strict, ESLint (including the lint rule that keeps UI components out
   of data and command services — `NFR-011`), Prettier, CI.
2. `firebase.json` + `.firebaserc` for project **`stockmok`**, emulators per §2. **Do not run
   `firebase init` against the live project, do not deploy, do not enable billing.**
3. `firestore.indexes.json` — IDX-01 … IDX-38. **Do not deploy it.**
4. Shared types, branded numerics, Zod schemas, converters, typed path builders.
5. Domain utilities, each with a unit test at the rounding and precedence boundaries — including
   `deriveStockStatus` proving that *exactly at the minimum is **not** low*.
6. Transition tables + `canTransition()` + their unit tests.
7. Read-side query functions named for their Q-ids, each carrying its `.limit()` and cursor.
8. `scripts/seed.ts` and `scripts/reset.ts`; `reset` must refuse `--target=production` unconditionally.
9. Factories and the emulator test harness; the property-test **generator** (Claude Code writes the
   assertions that touch security).
10. `README`: emulator start, seed, verify, and the deploy order (indexes → rules → functions → build →
    hosting) as documentation only.

## 7. DO NOT IMPLEMENT

Security Rules · any command body · `defineCommand()` · audit or notification writers · cross-tenant
projection logic · the React app · Cloud Storage · App Check · Firestore triggers · HTTP endpoints ·
a scheduled reconciliation job · a distributed counter · full-text search · a migration (there is no
legacy data) · anything for Release C or D.

## 8. TESTS YOU OWN

Unit tests for every domain utility and transition table · schema round-trip tests (Zod → converter →
Firestore → converter → Zod) · seed reconciliation `T-SEED-01` (DB-08 §6.5) · factory smoke tests ·
a test asserting `firestore.indexes.json` contains exactly the DB-04 §7 set — **no extra index, no
missing index**.

**Claude Code owns:** all rules tests, all command tests, `T-INT-03`, all `T-SEC-*`, all `T-XFER-*`
security assertions, all concurrency tests.

## 9. VALIDATION — the gate you must pass before handing back

```bash
npm run verify        # tsc --noEmit && eslint . && vitest run
npm run emu:clean &   # emulators start cleanly on 9099/8080/5001/5000/4000
npm run seed          # completes, idempotent, second run changes nothing
npm run test:seed     # T-SEED-01 green
```

Then assert by hand: `Q-050 = 12` · low `= 4` · out `= 1` · value `= LKR 564,200.00` · MEAT-001
`= 18.000 KG` · ledger `= 17` movements · Fresh Foods `200 PACK` / `300 KG` · `CKN-B5` published with
`orderUnit == baseUnit`.

## 10. EXPECTED OUTPUT

A repository that starts emulators, seeds the canonical dataset through the command layer, reconciles to
LKR 564,200.00, type-checks clean, lints clean, passes its own tests in CI, and has **no Security Rules
and no command bodies** — those are the next agent's work, and the interfaces they need are already
typed and waiting.

## 11. STOP CONDITIONS — stop and report, do not decide

- A field, enum, path, index or command in DB-02/04/06 is ambiguous or contradicts another DB file.
- The seed cannot reconcile to LKR 564,200.00 / 12 / 4 / 1 / 17.
- A query you need has no Q-id, or a Q-id has no index.
- You believe an index is missing, redundant or wrong.
- Implementing something requires a Security Rule, a command body, a trigger or an HTTP endpoint.
- Anything requires enabling billing, deploying, or writing to the live `stockmok` project.
- You are tempted to add a role, a path, a movement type, a command, a client write surface, or a
  collection-group query.
- A frozen design surface appears to need data the schema does not provide.

**You may not approve a scope change. Neither may any other agent.**

---

## 12. Shared contract map — what goes where, next

These files are the interface between Codex, Claude Code and the frontend agent. Create the **stubs and
types**; leave security semantics to Claude Code.

| File | Contents | Owner |
|---|---|---|
| `docs/implementation/DOMAIN_TYPES.md` | every entity, enum and branded numeric from DB-02, in TypeScript | **Codex** |
| `docs/implementation/FIREBASE_PATH_CONTRACT.md` | DB-01 §4 paths + deterministic ids as typed builders | **Codex** |
| `docs/implementation/COMMAND_CONTRACTS.md` | all 36 command signatures: input, result, error codes, idempotency flag — from DB-06 | **Codex** authors types · **Claude Code** authors semantics |
| `docs/implementation/FRONTEND_BACKEND_CONTRACT.md` | Q-id → query function → screen; command → action id; error code → user-facing copy | Codex + frontend |
| `docs/implementation/OWNERSHIP_MAP.md` | which agent owns which directory; the "must not touch" lists from §4 | **Codex** |
| `docs/implementation/INTEGRATION_STATUS.md` | living checklist: schema ✔ · indexes ✔ · seed ✔ · rules ☐ · commands ☐ · UI ☐ | all agents |

And later, as source: `src/shared/types/` · `src/shared/contracts/` · `src/shared/schemas/`.

**Do not create production source during the run that produces these documents.** Types, schemas and
contracts are the deliverable; screens and command bodies are not.
