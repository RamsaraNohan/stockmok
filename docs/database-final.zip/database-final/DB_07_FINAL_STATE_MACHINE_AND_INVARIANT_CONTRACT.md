# DB-07 — FINAL STATE MACHINE AND INVARIANT CONTRACT

**Status:** FROZEN. Every persistent state machine, every legal and forbidden transition, and every
non-negotiable system invariant.
**Implementation rule:** each machine is a **transition table in shared code**, unit-tested, and consulted
by `defineCommand()` step 7 — so an illegal transition is rejected in **one** place rather than in each
command.

```ts
type Transition<S, A> = { from: S; action: A; to: S; actor: ActorRule; guard?: Guard }
canTransition(machine, from, action, ctx) -> Result<to, 'INVALID_TRANSITION'>
```

## 0. Universal rules

- A transition not present in a table is **forbidden**. There is no default-allow branch.
- A correctly authorized user performing a forbidden transition is still rejected (`06` §4, last clause).
- Every transition writes its audit row and, where the entity has one, its history row, **inside the same
  transaction as the state change**.
- Terminal states have no outbound transition and no UI action; the control is **absent**, not disabled.
- Stale submissions re-read current state inside the transaction and are rejected, never merged.

---

## 1. Membership

| From | Action | To | Actor | Guard |
|---|---|---|---|---|
| *(invitation ACCEPTED)* | accept | `ACTIVE` | matching authenticated invitee | email matches `emailNormalized` |
| `ACTIVE` | suspend | `SUSPENDED` | `ADMINS` | target is **not** the canonical Owner |
| `SUSPENDED` | reactivate | `ACTIVE` | `ADMINS` | target is not the canonical Owner |
| `ACTIVE` \| `SUSPENDED` | remove | `REMOVED` | `ADMINS` | target is not the canonical Owner |

**Terminal:** `REMOVED` — no restore action exists.
**Forbidden:** any transition targeting the canonical Owner (`organizations/{orgId}.ownerUid`); a
self-suspension that would leave the organization ownerless; creating a second `OWNER`.
**Side effects:** `users/{uid}/memberships/{orgId}` is written in the same transaction (`INV-20`), plus a
notification to the affected member and an audit row.

## 2. Invitation

| From | Action | To | Actor |
|---|---|---|---|
| *(none)* | create | `PENDING` | `ADMINS` |
| `PENDING` | accept | `ACCEPTED` | matching authenticated invitee |
| `PENDING` | expire | `EXPIRED` | system — **evaluated on read**, never by a scheduled job |
| `PENDING` | revoke | `REVOKED` | `ADMINS` |

**Terminal:** `ACCEPTED`, `EXPIRED`, `REVOKED`.
**Guards:** single-use; 7-day expiry; bound to one organization and one normalised email; only the
SHA-256 `tokenHash` is stored and the raw token is returned exactly once and never logged; the invited
role may never be `OWNER`.
**Idempotency:** accepting twice returns the same result; accepting when already an ACTIVE member
succeeds without creating a duplicate membership (`FR-TEAM-011`).
**Distinct failures, all tested:** `INVITE_EMAIL_MISMATCH` · `INVITE_EXPIRED` · `INVITE_NOT_PENDING` ·
`not-found`. They are never collapsed into one message.

## 3. Product and Category

| Entity | From | Action | To | Actor | Guard |
|---|---|---|---|---|---|
| Product | `ACTIVE` | archive | `ARCHIVED` | `INVENTORY_WRITERS` | – |
| Product | `ARCHIVED` | restore | `ACTIVE` | `INVENTORY_WRITERS` | – |
| **Category** | `ACTIVE` | archive | `ARCHIVED` | `INVENTORY_WRITERS` | **backend command only (DB-CR-012)** — no ACTIVE product may reference it. The frozen design blocks category archive *"by physical truth rather than by permission"*, and that check is an unbounded query a rule cannot express. |
| **Category** | `ARCHIVED` | restore | `ACTIVE` | `INVENTORY_WRITERS` | always permitted |

**Consequences:** an archived product is excluded from new purchase orders and new mappings, hidden from
active lists by default and visible under the archived filter. **Historical movements and purchase-order
snapshots remain intact and visible** — a line always renders from its own snapshot.
**Forbidden:** hard delete, by anyone, at any layer.
**Immutability:** `baseUnit` may not change once any movement exists for the product.

## 4. Warehouse

| From | Action | To | Actor | Guard |
|---|---|---|---|---|
| `ACTIVE` | archive | `ARCHIVED` | `INVENTORY_WRITERS` | **backend command only** — every balance for that warehouse is zero **and** no open receiving workflow targets it |
| `ARCHIVED` | restore | `ACTIVE` | `INVENTORY_WRITERS` | always permitted |

Both guards are unbounded queries that Security Rules cannot express, which is why rules explicitly deny
a client setting `status: 'ARCHIVED'` and why the checks run as `.limit(1)` queries **inside** the
archiving transaction — stock added concurrently cannot slip past them.
The **default warehouse** may not be archived while it holds that status.
**A1 consequence:** the frozen archive refusal offers *"Transfer this stock"*, which is now a real action
(`SCREEN-053`) rather than a dead end.

## 5. Private partner

`ACTIVE → DEACTIVATED`, by `PARTNER_WRITERS`. No side effects, so it needs no command and is a
client write. A deactivated supplier is unavailable to new purchase orders; history is retained.
**Forbidden:** hard delete.

## 6. Connection

```text
(none) ──request──▶ PENDING ──accept──▶ ACTIVE ──disable──▶ DISABLED
                       └────reject────▶ REJECTED
REJECTED | DISABLED ──request──▶ PENDING        (a fresh request may be raised)
```

| From | Action | To | Actor |
|---|---|---|---|
| *(none)* \| `REJECTED` \| `DISABLED` | request | `PENDING` | `PARTNER_WRITERS` of the **buyer** |
| `PENDING` | accept | `ACTIVE` | `PARTNER_WRITERS` of the **supplier** |
| `PENDING` | reject | `REJECTED` | `PARTNER_WRITERS` of the **supplier** |
| `ACTIVE` | disable | `DISABLED` | **`ADMINS` only** — Procurement Manager cannot disable |

**Forbidden:** a duplicate request while `PENDING` or `ACTIVE` (prevented structurally by
`txn.create` on the deterministic id `{buyerOrgId}__{supplierOrgId}`); self-connection; **re-enable** —
there is no reconnect button, flow, command or reactivation feature, and the disabled record says so
plainly with no action.
**Direction matters:** a reverse relationship is a separate document, so two businesses can be each
other's supplier without ambiguity.
**`DISABLED` blocks new mappings and new connected POs but leaves every historical mapping, purchase
order and stock movement intact and readable by the legitimate parties** (`SC-17`).

## 7. Mapping

| From | Action | To | Actor |
|---|---|---|---|
| *(created, backend-validated)* | create | `VERIFIED` | `PARTNER_WRITERS` of the **buyer** |
| `VERIFIED` | disable | `DISABLED` | `PARTNER_WRITERS` of the buyer |

**Terminal:** `DISABLED`. **`PENDING` and `REJECTED` are B-PLUS and must never appear as a mapping
status pill.**

Server re-validates, in this order, refusing to trust any of it from the client:

1. caller is an ACTIVE member of `buyerOrgId` with a `PARTNER_WRITERS` role;
2. `connections/{connectionId}` exists, `status == 'ACTIVE'`, and its `buyerOrgId` is the caller's org;
3. the buyer product exists, belongs to the buyer org, and is `ACTIVE`;
4. the supplier catalog item exists under that connection's `supplierOrgId`, is `published`, and its
   `partnerSkuNormalized` equals the normalised typed SKU — **the typed SKU is only ever a lookup key,
   never the stored link** (`BR-008`, `FR-NET-014`);
5. `semanticConfirmed === true` — **a valid SKU alone is not sufficient** (`BR-009`);
6. `supplierToBuyerBaseFactorMilli > 0`;
7. no existing `VERIFIED` mapping already links this buyer product to this supplier item.

Seven refusal states, all drawn: no active connection · SKU not found · item not published · semantic
match declined · invalid factor · connection went stale before submit · duplicate mapping.

## 8. Private purchase order

```text
DRAFT ──order──▶ ORDERED ──receive──▶ PARTIALLY_RECEIVED ──receive──▶ RECEIVED
  │                 │                        └──receive──▶ PARTIALLY_RECEIVED
  └──cancel──▶ CANCELLED ◀──cancel── (only while receivedTotal == 0)
```

| From | Action | To | Guard |
|---|---|---|---|
| `DRAFT` | order | `ORDERED` | ≥ 1 valid line; supplier ACTIVE; every product ACTIVE; `orderNumber` allocated from the counter; **snapshots frozen** |
| `DRAFT` | cancel | `CANCELLED` | – |
| `ORDERED` | cancel | `CANCELLED` | **only while `receivedTotal == 0`** |
| `ORDERED` | receive | `PARTIALLY_RECEIVED` \| `RECEIVED` | `0 < receive ≤ outstanding`, per line |
| `PARTIALLY_RECEIVED` | receive | `PARTIALLY_RECEIVED` \| `RECEIVED` | same |

**Terminal:** `RECEIVED`, `CANCELLED`.
**Forbidden and never displayed:** `SUBMITTED`, `ACCEPTED`, `REJECTED`, `SHIPPED` — an external private
supplier is not a Stockmok user and cannot perform an in-platform action. The UI must never show an
in-platform "Supplier Accepted" state for a private supplier.
**Forbidden:** cancellation after any receipt (`INVALID_TRANSITION`); editing after `ORDERED`;
over-receipt (`OVER_RECEIPT`).

## 9. Connected purchase order

```text
DRAFT ──submit──▶ SUBMITTED ──accept──▶ ACCEPTED ──ship──▶ SHIPPED
  │                  │ └──reject──▶ REJECTED                  │
  └─cancel─▶ CANCELLED ◀──cancel──┘                           ▼
                                        PARTIALLY_RECEIVED ⇄ (more receipts)
                                                    └──▶ RECEIVED
```

| From | Action | To | Actor |
|---|---|---|---|
| `DRAFT` | submit | `SUBMITTED` | buyer `PO_WRITERS` |
| `DRAFT` | cancel | `CANCELLED` | buyer `PO_WRITERS` |
| `SUBMITTED` | accept | `ACCEPTED` | **supplier** `PO_WRITERS` |
| `SUBMITTED` | reject | `REJECTED` | supplier `PO_WRITERS` |
| `SUBMITTED` | cancel | `CANCELLED` | buyer `PO_WRITERS` |
| `ACCEPTED` | ship | `SHIPPED` | supplier `PO_WRITERS` |
| `SHIPPED` | receive | `PARTIALLY_RECEIVED` \| `RECEIVED` | buyer `RECEIVERS` |
| `PARTIALLY_RECEIVED` | receive | `PARTIALLY_RECEIVED` \| `RECEIVED` | buyer `RECEIVERS` |

**Terminal:** `RECEIVED`, `REJECTED`, `CANCELLED`.
**Forbidden and non-existent:** `PARTIALLY_SHIPPED` (`BR-020`); cancellation after `ACCEPTED`
(`FR-CPO-004`); a buyer performing a supplier transition or vice-versa; a third organization reading the
order at any path.
**Guards on every transition:** an ACTIVE connection re-read **inside** the transaction; the actor's
organization matching the correct side of the canonical record; snapshots immutable after `SUBMITTED`.
**Buyer stock is unchanged at `SHIPPED`.** Outstanding is tracked in supplier order units.

## 10. Stock — the ledger has no state machine, and that is the point

`StockMovement` has exactly one state: **written**. It is immutable and append-only forever. There is no
edit, no void, no reversal flag and no archive — not even a disabled control. **A wrong entry is answered
with a new entry carrying a reason**, which is why every correction is itself a movement.

`stock.transfer` is the only stock operation that writes **two** movements. They are created together,
share one `transferId`, and neither can exist without the other.

---

## 11. Invariants

Non-negotiable. `INV-01 … INV-21` are inherited verbatim from `05` §8; `INV-22 … INV-24` are added by
amendment A1.

| ID | Invariant |
|---|---|
| INV-01 | A `StockMovement` belongs to exactly one organization, product and warehouse. |
| INV-02 | A `StockMovement` is immutable once written. |
| INV-03 | `StockBalance.onHandMilli` equals the signed sum of movements for that product **and** warehouse — **exactly**, because quantities are integers. |
| INV-04 | `ProductStockSummary.onHandMilli` equals the sum of that product's balances. |
| INV-05 | Every stock mutation has an `operationId` and a `CommandReceipt`. |
| INV-06 | Replaying an `operationId` with an identical payload creates no duplicate effect; replaying with a different payload is rejected. |
| INV-07 | A `VERIFIED` mapping resolves to a stable buyer Product and a stable supplier `PartnerCatalogItem`. |
| INV-08 | A connected purchase order requires an ACTIVE connection at creation **and** at submission. |
| INV-09 | Connected purchase-order line snapshots are immutable after `SUBMITTED`. |
| INV-10 | Supplier SHIP changes supplier inventory only. |
| INV-11 | Buyer RECEIVE changes buyer inventory only. |
| INV-12 | Received quantity never exceeds outstanding quantity. |
| INV-13 | Public and partner projections contain only explicitly copied, allow-listed fields. |
| INV-14 | A connection grants no access to private tenant data. |
| INV-15 | Historical references remain resolvable after archive or disable. |
| INV-16 | A public handle resolves to exactly one organization. |
| INV-17 | A `PartnerCatalogItem.orderUnit` equals its source product's `baseUnit`. |
| INV-18 | `stockValueMinor == roundHalfUp(onHandMilli × purchaseCostMinor / 1000)` at all times, including after a cost change. |
| INV-19 | A connected purchase order's canonical record and both projections always agree on status and quantities, because all three are written in one transaction. |
| INV-20 | `users/{uid}/memberships/{orgId}` always agrees with `organizations/{orgId}/members/{uid}`. |
| INV-21 | No client can delete any document in any collection. |
| **INV-22** | **A `TRANSFER_OUT` exists if and only if exactly one `TRANSFER_IN` shares its `transferId`, with equal absolute quantity, the same product, the same unit, and different warehouses.** |
| **INV-23** | **A transfer leaves `ProductStockSummary.onHandMilli`, `availableMilli`, `stockStatus` and `stockValueMinor` unchanged. The summary is not written, which makes INV-04 hold by construction.** |
| **INV-24** | **`StockMovement.balanceAfterMilli` equals the `StockBalance.onHandMilli` of that movement's own product-and-warehouse immediately after the movement was applied.** |

`INV-03`, `INV-04`, `INV-06`, `INV-10`, `INV-11`, `INV-18`, `INV-19`, `INV-20`, `INV-22`, `INV-23` and
`INV-24` are asserted after **every** command in the randomised property test. They are not
documentation; they are executable.

---

## 12. Derived-value contracts

Every persisted duplicate names its source, its owner, its trigger and its repair.

| `DERIVED_VALUE_ID` | DV-01 `StockBalance.onHandMilli` |
|---|---|
| Source of truth | `stockMovements` for that product **and** warehouse |
| Derived document | `stockBalances/{productId}__{warehouseId}` |
| Calculation | signed sum of movements |
| Update owner | stock commands only (C-13, C-14, C-17, **C-33**, C-29, C-30) |
| Trigger | every movement |
| Atomic with source | **YES** — same transaction |
| Consistency | strong |
| Reconciliation | `sum(movements) == balance` after every command in the property test |
| Read cost | 1 |
| Stale behaviour | impossible; a balance without its movement cannot be written |

| DV-02 `ProductStockSummary.onHandMilli` / `availableMilli` |
|---|
| Source: the product's `stockBalances`. Owner: stock commands **except `stock.transfer`** (INV-23). Trigger: any movement that changes a product total. Atomic: YES. Consistency: strong. Reconciliation: `sum(balances) == summary`. Read cost 1. Stale: impossible. `availableMilli == onHandMilli` while `reservedMilli` is constant 0. |

| DV-03 `ProductStockSummary.stockStatus` |
|---|
| Source: `onHandMilli` + `product.minimumStockMilli`. Calculation: `out ≤ 0` → `OUT_OF_STOCK`; `min > 0 && on < min` → `LOW_STOCK`; else `IN_STOCK`. **Out-of-stock takes precedence; exactly at the minimum is not low.** Owner: stock commands and `product.update` (when the minimum changes) and `product.setStatus`. Atomic: YES. Drives the low-stock notification **on transition only**. |

| DV-04 `ProductStockSummary.stockValueMinor` |
|---|
| Source: `onHandMilli` × `product.purchaseCostMinor`. Owner: stock commands **and `product.update` when the purchase cost changes** — `FR-INV-013`. Atomic: YES. This is what makes Inventory Value a bounded `sum()` instead of an unbounded scan. **Replacement cost, not weighted average** — stated in the UI and the report. Drift is impossible because both writers are transactional; a cost change that skipped the summary would be caught by `INV-18` in the property test. |

| DV-05 `users/{uid}/memberships/{orgId}` |
|---|
| Source: `organizations/{orgId}/members/{uid}`. Owner: team commands + `org.create`. Atomic: YES (`INV-20`). Read cost 1 per organization. Stale: impossible — a suspension updates the mirror in the same transaction, so the workspace switcher never offers a lost workspace. |

| DV-06 connected-PO projections |
|---|
| Source: `connectedPurchaseOrders/{poId}`. Derived: both organizations' `purchaseOrders/{poId}` + items + history. Owner: `cpo.*`. Atomic: YES (`INV-19`) — all three written in one transaction, same `poId`, so reconciliation by id is trivial. Stale: impossible. |

| **DV-07 `StockMovement.balanceAfterMilli`** *(DB-CR-006)* |
|---|
| Source: the `StockBalance` value computed in the same transaction. Owner: every stock command. Atomic: YES. Consistency: strong and **frozen at write time** — this is a historical fact, not a live value, and it must never be recomputed or backfilled from a later balance. Reconciliation: `INV-24`; the property test replays the ledger in `createdAt` order per product-and-warehouse and asserts each row's `balanceAfterMilli` equals the running total. Read cost 0 — it is already on the row the ledger renders. |

| DV-08 `organizationDirectory` and `partnerCatalog` projections |
|---|
| Source: `organizations/{orgId}` / `products`. Owner: `org.create`, `partnerCatalog.*`. Atomic: YES. Allow-listed fields only (`INV-13`); the exact key set is asserted by `T-SEC-16`. **Drift here is a privacy defect, not a correctness one**, which is why the test asserts the key set rather than the values. |

| **DV-10 `ProductStockSummary` denormalised product fields** *(DB-CR-011)* |
|---|
| Fields: `productName`, `internalSku`, `internalSkuNormalized`, `categoryId`, `categoryName`, `productStatus`, `baseUnitPriceMinor`, `preferredSupplierName`, `productUpdatedAt`. Source of truth: `organizations/{orgId}/products/{productId}` and `categories/{categoryId}`. Owner: `product.create`, `product.update`, `product.setStatus` — each already writes the summary, so this adds a field set, not a write. Atomic: **YES**, same transaction. Consistency: strong. Reconciliation: a property-test assertion that every summary's denormalised fields equal its product's. **Unlike DV-09 these must NOT drift** — they back a live list, not a historical snapshot. A category rename must therefore fan out to the summaries of that category's products: bounded by `limit(500)` inside `category.update`, with a documented refusal above 500 products in one category. Read cost 0 — the list already reads the summary. |

| DV-09 denormalised display fields (`productNameSnapshot`, `actorName`, `organizationName`, PO line snapshots) |
|---|
| Deliberately **allowed to drift**. A snapshot records what was true at the time and must not be updated when the source changes — that is its entire purpose (`BR-012`). Renaming a product leaves every historical order and ledger row unchanged, which is the behaviour `SC-08` asserts. |

**No manually editable KPI document exists anywhere, and none may be introduced.** Every dashboard figure
is an aggregation query over an indexed field (DB-04 §6). Distributed counters are deliberately avoided
as premature.

**Drift policy.** Because every derived value is written in the same transaction as its source, drift can
arise only from a code defect. The response is a code fix plus a one-off reconciliation script — **not a
scheduled reconciler**, which would mask the defect and give false confidence.

---

## 13. Known limits, stated honestly

1. **Per-product summary hotspot.** `productStockSummaries/{productId}` is written by every movement for
   that product. Irrelevant at coursework scale; the future path is sharded counters or a periodic
   rollup. `stock.transfer` avoids it entirely.
2. **Cross-tenant reads cost a function call.** Partner-catalog browsing is not realtime. Accepted trade
   for a provably safe boundary.
3. **Role lists are duplicated between `firestore.rules` and TypeScript.** Rules cannot import code.
   Mitigated by `T-SEC-17`.
4. **No App Check.** A stolen ID token could call callables directly; every callable still enforces
   membership and role, so the blast radius is what that user could already do.
5. **Audit is tamper-resistant, not tamper-evident.**
6. **Single region**, no failover.
7. **Cold starts** of 1–3 s after idle.
8. **`effectiveAt` back-dating** applies to opening balances only and never affects ordering or balance
   arithmetic; the ledger is ordered by `createdAt` alone.
