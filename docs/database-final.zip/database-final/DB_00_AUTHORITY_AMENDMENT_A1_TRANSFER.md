# DB-00 — AUTHORITY AMENDMENT A1 — INTER-WAREHOUSE TRANSFER

**Instrument type:** owner-approved authority amendment
**Raised by:** DB-CR-004 (`STOCKMOK_DATABASE_FRONTEND_INGESTION_STOP.md` §3)
**Decided by:** Owner, 2026-08-15
**Status:** APPROVED — binding on all downstream implementation

```
DB_CR_004                 = RESOLVED
INTER_WAREHOUSE_TRANSFER  = INCLUDE
TRANSFER_CURRENT_RELEASE  = YES
TRANSFER_RELEASE          = A
DB_CR_005                 = RESOLVED
```

The owner's decision supersedes every prior classification of inter-warehouse transfer as Future /
Release D. Transfer is **not** removed from the approved frontend. This document is the minimal,
exact delta each frozen authority requires; DB-01 → DB-10 are written against it.

**Scope guard.** This amendment authorises exactly one new capability. It adds no Release C or
Release D surface, no sales/outbound subsystem, no multi-product transfer, no cross-organization
movement, no transfer approval workflow and no in-transit state. Anything beyond a single-product,
same-organization, two-warehouse, immediately-applied stock move remains out of scope.

---

## 1. Design authority already satisfied — no design change required

The workflow is already drawn and owner-approved, so **no frozen UI is modified by this amendment**.
Verified in the canonical (patched) Gate 6 artifact `cb94a73c…`, board **6i**:

> **Move stock between store rooms** — From `Main Store ▾` · To `Cold Room ▾` · Product
> `Basmati Rice · DRY-001 ▾` · Quantity `50.000 KG` · Main Store `250.000 → 200.000 KG` ·
> Cold Room `0.000 → 50.000 KG` · **Total stock unchanged · 250.000 KG**
> *"A transfer never changes what you own, only where it is — and it writes both halves at once."*

Corroborating frozen content: Gate 6 ledger *"A transfer is two lines — out of one store room, into
another, at the same moment, each with its own resulting balance"*; Gate 12 refusal frame
*"TRANSFER · same room twice"*; Gate 12 warehouse-archive remedy action *"Transfer this stock"*;
Gate 11 *"Stock moves only through an adjustment, a transfer or a receipt"*; Gate 14 (approved)
*"transfer writing both halves at once — Drawn"*; `DEC-012`; `CHG-024`.

**Single product per transfer is proven by existing authority.** The drawn form carries exactly one
`Product ▾` selector. No multi-line transfer surface exists anywhere in the frozen package. The
owner's "unless existing authority proves otherwise" therefore resolves to **one product per
transfer operation**.

---

## 2. Amendments by authority file

### A1-01 · `02_FINAL_REQUIREMENTS_SPECIFICATION.md` §4.5 — add three requirements

| ID | Priority | Requirement |
|---|---|---|
| FR-STOCK-018 | **A-MUST** | An authorised user may transfer a quantity of one product from one ACTIVE warehouse to another ACTIVE warehouse within the same organization. The transfer executes through a trusted backend command. |
| FR-STOCK-019 | **A-MUST** | A transfer writes a paired, immutable `TRANSFER_OUT` and `TRANSFER_IN` movement sharing one `transferId`, and updates both `StockBalance` documents, in a single atomic transaction. Partial persistence is impossible. Total organization stock for that product is unchanged. |
| FR-STOCK-020 | **A-MUST** | Source and destination warehouses must differ; quantity must be greater than zero; the resulting source balance must not be negative. Each is rejected with a distinct reason code. |

### A1-02 · `03_FINAL_SCOPE_FREEZE.md` — move transfer from future to Release A

- §A5 *Stock integrity* — append: *"· inter-warehouse transfer with paired movements and an unchanged organization total"*.
- §7 *Deliberate coursework simplifications* — add a row: *Transfer · single product, single quantity, immediate · multi-line transfer requests and in-transit state*.
- No entry in §6 (Release D) is added or removed; inter-warehouse transfer was never listed there.

### A1-03 · `05_FINAL_DOMAIN_AND_DATA_CONTRACT.md` — the substantive delta

1. **§5.16 movement types.** Release A/B set becomes:
   `OPENING_BALANCE · ADJUSTMENT_IN · ADJUSTMENT_OUT · PURCHASE_RECEIPT · CONNECTED_DISPATCH_OUT · `**`TRANSFER_OUT · TRANSFER_IN`**.
   Remove `TRANSFER` from the *Future* list. Source types gain `TRANSFER`.
2. **§5.16 new fields on `StockMovement`** — see DB-02 §4.11 for the full contract:
   `transferId?` · `counterpartWarehouseId?` · `balanceAfterMilli` · `adjustmentReason?` · `note?` · `effectiveAt`.
3. **§11 Future compatibility** — strike *"inter-warehouse transfers"*.
4. **New invariants:**

| ID | Invariant |
|---|---|
| INV-22 | A `TRANSFER_OUT` movement exists if and only if exactly one `TRANSFER_IN` movement shares its `transferId`, and the two carry equal absolute quantities, the same product, the same unit and different warehouses. |
| INV-23 | A transfer leaves `ProductStockSummary.onHandMilli`, `availableMilli`, `stockStatus` and `stockValueMinor` unchanged. The summary document is therefore **not written** by `stock.transfer`, which makes INV-04 hold by construction rather than by arithmetic. |
| INV-24 | `StockMovement.balanceAfterMilli` equals the `StockBalance.onHandMilli` of that movement's own product-and-warehouse immediately after the movement was applied. |

### A1-04 · `06_FINAL_SECURITY_AND_RBAC_MODEL.md` — one capability row, one list entry

- §5 matrix — insert after *Adjust stock*:

  | Capability | Owner | Admin | Inventory Mgr | Procurement Mgr | Storekeeper | Analyst | Viewer |
  |---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
  | **Transfer stock between warehouses** | ✔ | ✔ | ✔ | ✘ | **✘** | ✘ | ✘ |

  **Reasoning, in the style of the existing resolved ambiguities.** Transfer is grouped with opening
  balance and adjustment on frozen board 6i, drawn in an Inventory Manager session, and it is a
  free-form quantity movement with no external document — the same property that excludes Storekeeper
  from *Adjust stock*. It is therefore `INVENTORY_WRITERS`, not `RECEIVERS`. Segregation of duties is
  preserved: a Storekeeper can receive documented goods but cannot silently relocate stock.
- §6.2 backend-command list — append `· inter-warehouse transfer`.
- §17 minimum security tests — add `T-SEC-24`: *a Storekeeper, Procurement Manager, Analyst or Viewer calling `stock.transfer` → denied*; and `T-SEC-25`: *a transfer naming a warehouse in another organization → denied after the membership and ownership reads*.

### A1-05 · `08_FINAL_TEST_AND_QA_MATRIX.md` — new test family

`T-XFER-01 … T-XFER-12`, all **P0**. Full definitions in DB-08 §6.4.

### A1-06 · `11_FINAL_FIREBASE_IMPLEMENTATION_ARCHITECTURE.md` — command, transaction, indexes

- §11 command catalog: **C-33 `stock.transfer`** · `INVENTORY_WRITERS` · Release A · idempotent **yes** · transaction **yes** · audit **yes**. With C-34, C-35 and C-36 the catalog becomes **36 commands**.
- §14 transaction boundaries: one new row, reproduced in DB-06 §6.
- §8 indexes: `IDX-20 … IDX-24` and `IDX-33 … IDX-38` (DB-04 §7). Note that `IDX-21` closes a pre-existing gap — `TABLE-006` already permitted a combined product **and** warehouse filter, for which no composite index was declared.
- §32 freeze statement is otherwise unchanged: no document moves zone, no client write path is added, no HTTP endpoint, no trigger, no data-derived rule read.

### A1-07 · `23_FINAL_UI_STATE_AND_PERMISSION_MATRIX.md` — remove the exclusion

- Header **Excluded** line: strike `transfer`. It now reads *"Release D sales, reservation and multi-level conversion"*.
- §3 hard matrix — add the *Transfer stock between warehouses* row: `FULL / FULL / FULL / HIDDEN / HIDDEN / HIDDEN / HIDDEN`.
- §7.2 — add: *Stock transfer · source ACTIVE warehouse → destination ACTIVE warehouse · O/A/IM only · same-warehouse and negative-result attempts refused inline.*
- §4 screen matrix — add `SCREEN-053` row: `FULL / FULL / FULL / HIDDEN / HIDDEN / HIDDEN / HIDDEN`.

### A1-08 · `19` and `22` — registry entries for an already-drawn surface

| New ID | Definition |
|---|---|
| `SCREEN-053` | **Stock Transfer** — modal / 390 px sheet, **not a route**. Hosted by `SCREEN-015` Warehouses and `SCREEN-013` Product Detail → Stock. Exactly analogous to `SCREEN-016` and `SCREEN-042`. |
| `FORM-024` | From warehouse; To warehouse; Product; Quantity + unit; read-only source-after, destination-after and unchanged-total previews. `operationId` generated when the modal opens. Validation: warehouses differ; quantity > 0; source result ≥ 0; both warehouses ACTIVE; product ACTIVE. |
| `ACTION-062` | **Transfer stock** — dialog submit. Outcome: paired atomic movements and both balances. Constraint: Owner / Admin / Inventory Manager; same organization only. |
| `STATE-044` | Transfer refused — source and destination are the same store room. (Drawn: Gate 12 *"TRANSFER · same room twice"*.) |

`SCREEN-053` state coverage: `L N R R R R R C` — Loading R, Empty N, Error R, Success R, Permission
denied R, Submitting R, Validation R, Confirmation C (contextual; a transfer is not destructive, so
`STATE-008` is required only when the movement reduces the source balance by more than 50 %, matching
the existing large-reduction rule).

---

## 3. DB-CR-005 — movement "Kind" taxonomy — **RESOLVED, no schema cost**

**The problem.** The frozen ledger states *"Plain words for every kind: Opening balance · Received ·
Issued · Transferred in · Transferred out · Correction. The Kind filter offers exactly these words and
nothing from the system underneath."* — six words against seven movement types.

**Resolution.** `movementKind` is a **derived display and filter value, not a persisted field.** Every
frozen word maps onto movement types with no ambiguity:

| Frozen UI word | Movement type(s) | Filter predicate |
|---|---|---|
| Opening balance | `OPENING_BALANCE` | `movementType == 'OPENING_BALANCE'` |
| Received | `PURCHASE_RECEIPT` | `movementType == 'PURCHASE_RECEIPT'` |
| **Issued** | `CONNECTED_DISPATCH_OUT` | `movementType == 'CONNECTED_DISPATCH_OUT'` |
| Transferred in | `TRANSFER_IN` | `movementType == 'TRANSFER_IN'` |
| Transferred out | `TRANSFER_OUT` | `movementType == 'TRANSFER_OUT'` |
| **Correction** | `ADJUSTMENT_IN`, `ADJUSTMENT_OUT` | `movementType in ['ADJUSTMENT_IN','ADJUSTMENT_OUT']` |

**Why "Issued" is the connected dispatch and not an adjustment.** The canonical Gate 6 adjustment form
was patched to carry an **enumerated** Reason — *"Recount correction · Damaged in storage · Expired ·
Wastage · Theft or loss · Other"* — and not one of those six is an issue. Every adjustment is therefore
a correction. `CONNECTED_DISPATCH_OUT` is the only movement that issues stock out of the workspace to
another party, so it is the only candidate for "Issued". This mapping reproduces the six frozen words
exactly, needs no new form field, no new persisted column and no new index, and leaves `FORM-009`
untouched.

**Consequence for the canonical seed.** Grand Ocean never dispatches and the seed contains no
transfer, so in the seeded buyer workspace the Kind filter legitimately returns zero rows for *Issued*,
*Transferred in* and *Transferred out*. This matches the frozen board, which states the whole record is
*"Twelve opening balances plus the five later movements on Chicken Breast"* — 17 movements, no invented
traffic. **The canonical seed is not amended by A1.**

**Firestore note.** `in` accepts up to 30 values and uses the same composite index as an equality on
the field, so *Correction* costs no additional index.

---

## 4. Two further contract corrections adopted with A1

Both are required by the frozen UI, neither needs an owner decision, and neither moves a document
between zones, adds a client write path, adds a trigger or adds a data-derived rule read — so both sit
inside the `11` §32 freeze.

### DB-CR-006 — `StockMovement.balanceAfterMilli` — **ADOPTED**
`TABLE-005` and `TABLE-006` both require a **Balance After** column and every drawn ledger row shows
one. It cannot be computed from a filtered, paginated, reverse-chronological page without reading the
whole ledger. Persist it as an immutable field written inside the transaction that already computes the
new balance. Governed by INV-24 and by derived-value contract `DV-07` (DB-07 §5).

### DB-CR-009 — adjustment `adjustmentReason` enum, `note`, and `effectiveAt` — **ADOPTED**
The canonical Gate 6 forms are more specific than `05` §5.16's free-text `reason?`:

- **Reason is a select**, not free text: `RECOUNT_CORRECTION · DAMAGED_IN_STORAGE · EXPIRED · WASTAGE · THEFT_OR_LOSS · OTHER`. Choosing `OTHER` makes `note` **required**.
- **`note`** is an optional bounded free-text field (drawn: *"Recounted the cold room shelf on Monday"*).
- **`effectiveAt`** — the opening-balance form carries *"As at 1 Aug 2026 ▾ · Cannot be later than today"*. Opening balances are back-datable for display; `createdAt` remains the immutable server timestamp and is the only ordering key. Balances are never recomputed from `effectiveAt`.

### DB-CR-010 — the connected DRAFT has no write path — **ADOPTED (gap closure, not new capability)**
`11` §9.3 permits a client write to `purchaseOrders/{poId}` **only while `supplierKind == 'PRIVATE'` and
`status == 'DRAFT'`**, and `05` §5.22 makes client DRAFT editing explicit for private orders only. But
`11` §11's catalog has no command that **creates or edits a connected draft** — `cpo.submit` is
`DRAFT → SUBMITTED` and presupposes the draft exists. `SCREEN-038` / `FORM-021` require a buyer to build
one. As written, a frozen UI action has no legitimate backend behaviour.

Left unclosed, the only way to make the screen work would be to widen rule 6 to connected drafts — which
would let a buyer create a purchase order client-side carrying a forged `counterpartyOrgId`,
`connectionId` and `mappingId`, none of which a rule can validate.

**Resolution: add `C-34 cpo.draftSave`** (`PO_WRITERS` of the buyer org, Release B, idempotent, transaction,
no audit). It creates or updates the buyer-tenant connected draft after server-validating the ACTIVE
connection, the VERIFIED mappings and the ACTIVE products. No client write path is added, no capability is
added — `FR-CPO-001` and `FR-CPO-015` already require exactly this behaviour. The draft still lives only in
the buyer's tenant and stays invisible to the supplier until `cpo.submit`.

### DB-CR-011 — the product list breached its own read budget — **ADOPTED**
The first draft read 25 `products` then joined 25 `productStockSummaries` by `documentId() in [...]`.
An `in` query still bills **one read per returned document**, so the page cost 50 reads against a frozen
`NFR-017` budget of 27. **Resolution:** `TABLE-001` is served entirely from `productStockSummaries`,
which now carries denormalised product display fields written in the same transaction that already
writes the summary. 25 reads, one collection. Governed by derived-value contract `DV-10`.

### DB-CR-012 — category archive is guarded and cannot be a client write — **ADOPTED**
The frozen design blocks category archive *"by physical truth rather than by permission"* — an archive is
refused while ACTIVE products still reference the category. That is an unbounded query, exactly the
warehouse-archive situation, and `06` §6.1 nevertheless listed categories as fully client-writable.
**Resolution:** `C-35 category.archive` / `category.restore` with a `limit(1)` guard inside the
transaction; rules deny a client setting `status`.

### DB-CR-013 — the default warehouse had two sources of truth — **ADOPTED**
A `warehouse.isDefault` boolean and `settings.defaultWarehouseId` would be two copies of one fact, and
"exactly one is true" is not expressible in a Security Rule while switching it is inherently a
two-document write. **Resolution:** `settings.defaultWarehouseId` is the only source of truth, the
`isDefault` field does not exist, and the frozen *"Make this the default store room"* control is
`C-36 warehouse.setDefault`.

### DB-CR-014 — `cpo.draftSave` must not be idempotent — **ADOPTED**
Receipts are never deleted in Release A/B. Giving a draft save an `operationId` would create one
permanent receipt document per keystroke-batch. A draft save is an upsert with no side effect and is
idempotent by nature. **Resolution:** no `operationId`, no receipt, no audit; it keeps its transaction
only to re-validate the connection, mappings and products server-side.

### DB-CR-007 — handle length — **RESOLVED by authority order**
`05` §3 and `11` §18 specify **3–30**; `19` `FORM-005` says 3–40. Two authorities to one, and 3–30 is a
strict subset. **3–30 binds.**

---

## 5. Blocker DB-B-01 — resolved by evidence, with a required repair

`STOCKMOK_FINAL_DESIGN_ARTIFACT_MANIFEST.md` remains factually wrong (8 of 10 canonical SHA-256 values
match no file; the Gate 6 "byte-identical" claim is false by 31,392 bytes). It is **no longer a blocker
for this pack**, because every rival pair is resolvable deterministically from the change register plus
content markers, and the residual staleness is provably non-database.

| Logical artifact | Resolved canonical file | Basis |
|---|---|---|
| Gate 6 | `…Dashboard Inventory **new**.dc.html` `cb94a73c` | Carries the frozen twelve-product seed; `CHG-027`. The manifest's own canonical hash is this file's hash. |
| Gate 7 | `…Private Procurement **new**.dc.html` `f8a7c504` | `Print` absent; `CHG-036`. |
| Gate 9 | `…Connected Workflows **new**.dc.html` `e1003987` | `@freshfoods` ×3, `Print` absent; `CHG-033`, `CHG-036`. |
| Design System, Gates 5, 8, 10, 11, 12, 14 | the single local copy | No rival exists. |

**Known-stale, non-database deltas** in the single-copy artifacts, already authoritatively resolved in
the change register and therefore mapped from the *record* rather than the file: `@fresh-foods` →
`@freshfoods` (Gates 8, 12 — `CHG-033`); the 390 px bottom-tab navigation (Gate 11 — `CHG-044`,
`MOBILE_BOTTOM_TAB_NAV = 0`); `reconnect` wording (Gate 8 — `CHG-041`). None touches a document, a
field, a query, a command, an RBAC cell or a privacy boundary.

**Residual risk, stated rather than hidden.** If a patched Gate 5/8/10/11/12 artifact exists outside
this repository and contains a further capability-level addition comparable to Transfer, this pack would
not know about it. Every board's full semantic content was read and Transfer was the only such finding.
**Required repair, non-blocking: correct the manifest** (re-hash all artifacts, invert the Gate 6/7/9
supersession, and either locate the patched Gate 5/8/10/11/12 files or record that the local copies are
pre-patch).

---

## 6. Amendment result

```
AUTHORITY_AMENDMENT          = A1
AMENDED_AUTHORITIES          = 02, 03, 05, 06, 08, 11, 19, 22, 23
NEW_COMMANDS                 = 4   (C-33 stock.transfer · C-34 cpo.draftSave · C-35 category.archive · C-36 warehouse.setDefault)
COMMAND_CATALOG_TOTAL        = 36
NEW_MOVEMENT_TYPES           = 2   (TRANSFER_OUT, TRANSFER_IN)
NEW_INVARIANTS               = 3   (INV-22, INV-23, INV-24)
NEW_INDEXES                  = 11  (IDX-20 … IDX-24 transfer/ledger · IDX-33 … IDX-38 second-pass corrections)
NEW_REGISTRY_ENTRIES         = 4   (SCREEN-053, FORM-024, ACTION-062, STATE-044)
NEW_SECURITY_TESTS           = 2   (T-SEC-24, T-SEC-25)
NEW_TEST_FAMILY              = T-XFER-01 … T-XFER-12
DESIGNS_MODIFIED             = NO
CANONICAL_SEED_MODIFIED      = NO
RELEASE_C_D_SCOPE_EXPANSION  = NONE
CROSS_ORG_TRANSFER           = FORBIDDEN
```
