# DB-06 — FINAL COMMAND AND TRANSACTION CONTRACT

**Status:** FROZEN. The complete command catalog, its authorization, its atomic write sets and its
failure guarantees.
**Total commands: 36.** Every one is a `onCall` callable produced by `defineCommand()`. **Zero HTTP
endpoints. Zero Firestore triggers.**

## 0. `defineCommand()` — the shared frame

Every command runs through the identical frame, so no step can be forgotten in the thirty-fourth command
written late on Day 11.

**Why `cpo.draftSave` is deliberately NOT idempotent.** A draft save is an upsert with last-write-wins
semantics and no side effect, so it is idempotent *by nature*. Giving it an `operationId` would create one
permanent `commandReceipt` document per save — receipts are never deleted in A/B — turning ordinary
editing into unbounded storage growth. It takes a transaction only because it must re-validate the
connection, the mappings and the products server-side before persisting.

```text
AUTH          context.auth.uid present                     → unauthenticated
INPUT         Zod schema (the same object the form used)   → invalid-argument
MEMBERSHIP    read organizations/{orgId}/members/{uid}     → permission-denied / NOT_A_MEMBER
STATUS        must be ACTIVE                               → permission-denied / MEMBERSHIP_NOT_ACTIVE
ROLE          role ON THAT DOCUMENT ∈ allowed              → permission-denied / ROLE_NOT_PERMITTED
─── open transaction ───────────────────────────────────────────────────────────
IDEMPOTENCY   read commandReceipts/{operationId}   ← FIRST READ
              exists + hash match  → return stored result, no side effects
              exists + hash differ → failed-precondition / OPERATION_REPLAYED_WITH_DIFFERENT_PAYLOAD
READ_SET      all reads, all bounded, all within the verified organization
OWNERSHIP     every referenced doc's organizationId == verified orgId → CROSS_TENANT_REFERENCE
VALIDATION    domain rules
STATE         transition table (DB-07) → failed-precondition / INVALID_TRANSITION
WRITE_SET     all writes
AUDIT         writeAudit(txn, …)
NOTIFY        notify(txn, …) — recipients resolved BEFORE any write, limit(50)
RECEIPT       txn.create(commandReceipts/{operationId})    ← LAST WRITE
─── commit ─────────────────────────────────────────────────────────────────────
RETURN        minimal result
```

**All reads precede all writes** — a Firestore requirement. The receipt is read **first** and written
**last**. Every in-transaction query carries `.limit()`.

**Failure guarantee, universal:** a command either commits its entire write set or writes nothing. There
is no partial state, no compensating write and no cleanup job anywhere in this architecture.

**Retry policy.** Callables are **not** automatically retried by the platform, so every retry is user- or
client-initiated and always carries the same `operationId`. Firestore retries the transaction body
internally on contention; the body is therefore pure and side-effect-free outside the transaction.

---

## 1. Catalog

`I` = requires `operationId` and is idempotent · `T` = transaction · `A` = writes audit.

| # | Command | Roles | Rel | I | T | A |
|---|---|---|:-:|:-:|:-:|:-:|
| C-01 | `org.create` | any authenticated user | A | ✔ | ✔ | ✔ |
| C-02 | `org.updateSettings` | `ADMINS` | A | – | – | ✔ |
| C-03 | `user.bootstrapProfile` *(optional; client `setDoc` covers it)* | self | A | ✔ | – | – |
| C-04 | `team.createInvitation` | `ADMINS` | A | ✔ | ✔ | ✔ |
| C-05 | `team.revokeInvitation` | `ADMINS` | A | – | – | ✔ |
| C-06 | `team.acceptInvitation` | authenticated invitee | A | ✔ | ✔ | ✔ |
| C-07 | `team.changeMemberRole` | `ADMINS` | A | – | ✔ | ✔ |
| C-08 | `team.setMemberStatus` | `ADMINS` | A | – | ✔ | ✔ |
| C-09 | `product.create` | `INVENTORY_WRITERS` | A | ✔ | ✔ | ✔ |
| C-10 | `product.update` | `INVENTORY_WRITERS` | A | – | ✔ | ✔ |
| C-11 | `product.setStatus` | `INVENTORY_WRITERS` | A | – | ✔ | ✔ |
| C-12 | `warehouse.archive` | `INVENTORY_WRITERS` | A | – | ✔ | ✔ |
| C-13 | `stock.recordOpeningBalance` | `INVENTORY_WRITERS` | A | **✔** | ✔ | ✔ |
| C-14 | `stock.adjust` | `INVENTORY_WRITERS` | A | **✔** | ✔ | ✔ |
| **C-33** | **`stock.transfer`** | **`TRANSFER_WRITERS`** | **A** | **✔** | **✔** | **✔** |
| C-15 | `po.order` | `PO_WRITERS` | A | ✔ | ✔ | ✔ |
| C-16 | `po.cancel` | `PO_WRITERS` | A | – | ✔ | ✔ |
| C-17 | `po.receive` | `RECEIVERS` | A | **✔** | ✔ | ✔ |
| C-18 | `connection.request` | `PARTNER_WRITERS` | B | ✔ | ✔ | ✔ |
| C-19 | `connection.respond` | `PARTNER_WRITERS` | B | ✔ | ✔ | ✔ |
| C-20 | `connection.disable` | `ADMINS` | B | – | ✔ | ✔ |
| C-21 | `partnerCatalog.publish` | `PARTNER_WRITERS` | B | – | ✔ | ✔ |
| C-22 | `partnerCatalog.unpublish` | `PARTNER_WRITERS` | B | – | ✔ | ✔ |
| C-23 | `partnerCatalog.list` *(read)* | `PARTNER_WRITERS` of a connected buyer | B | – | – | – |
| C-24 | `partnerCatalog.lookupBySku` *(read)* | as above | B | – | – | – |
| C-25 | `mapping.create` | `PARTNER_WRITERS` | B | ✔ | ✔ | ✔ |
| C-26 | `mapping.disable` | `PARTNER_WRITERS` | B | – | ✔ | ✔ |
| **C-34** | **`cpo.draftSave`** *(DB-CR-010)* | `PO_WRITERS` (buyer) | B | – | ✔ | – |
| **C-35** | **`category.archive` / `category.restore`** *(DB-CR-012)* | `INVENTORY_WRITERS` | A | – | ✔ | ✔ |
| **C-36** | **`warehouse.setDefault`** *(DB-CR-013)* | `INVENTORY_WRITERS` | A | – | ✔ | ✔ |
| C-27 | `cpo.submit` | `PO_WRITERS` (buyer) | B | **✔** | ✔ | ✔ |
| C-28 | `cpo.respond` | `PO_WRITERS` (supplier) | B | **✔** | ✔ | ✔ |
| C-29 | `cpo.ship` | `PO_WRITERS` (supplier) | B | **✔** | ✔ | ✔ |
| C-30 | `cpo.receive` | `RECEIVERS` (buyer) | B | **✔** | ✔ | ✔ |
| C-31 | `cpo.cancel` | `PO_WRITERS` (buyer) | B | – | ✔ | ✔ |
| C-32 | `storefront.publish` / `unpublish` | `ADMINS` | **C — NOT BUILT** | – | ✔ | ✔ |

Deployment names map dot-case → camelCase (`stock.transfer` → `stockTransfer`), exported individually
from `index.ts` so Firebase deploys each as a separate function with its own logs, metrics and redeploy.

---

## 2. C-33 `stock.transfer` — the A1 command, in full

**PURPOSE** Move a quantity of one product from one ACTIVE warehouse to another ACTIVE warehouse within
the same organization, writing both halves of the ledger at once.

**INPUT**
```ts
{ operationId: string,        // UUID v4, generated when the modal opens
  orgId: string,              // routing hint only — never a claim
  productId: string,
  fromWarehouseId: string,
  toWarehouseId: string,
  quantityMilli: integer }    // > 0
```

**AUTH / MEMBERSHIP / ROLE** authenticated · ACTIVE membership in `orgId` ·
role ∈ `TRANSFER_WRITERS = ['OWNER','ADMIN','INVENTORY_MANAGER']`.

**PRECONDITIONS**
1. `fromWarehouseId != toWarehouseId`
2. `quantityMilli > 0` and is an integer
3. product exists, belongs to `orgId`, `status == 'ACTIVE'`
4. both warehouses exist, belong to `orgId`, `status == 'ACTIVE'`
5. source balance exists and `onHandMilli >= quantityMilli`

**READ_SET** *(all inside the transaction, all by deterministic id — no scan)*
```
commandReceipts/{operationId}                              ← FIRST
products/{productId}
warehouses/{fromWarehouseId}
warehouses/{toWarehouseId}
stockBalances/{productId}__{fromWarehouseId}
stockBalances/{productId}__{toWarehouseId}                 ← may not exist
```

**VALIDATION** Zod schema; the five preconditions; `quantityMilli` precision ≤ 3 dp;
`unit` taken from the product, never from the payload.

**LEGAL_SOURCE_STATE** product `ACTIVE`; both warehouses `ACTIVE`; source `onHandMilli >= quantityMilli`.

**ATOMIC_WRITE_SET** — six documents, exactly

| # | Document | Write |
|---|---|---|
| 1 | `stockMovements/{outId}` | `create` · `TRANSFER_OUT` · `signedQuantityMilli = -q` · `warehouseId = from` · `counterpartWarehouseId = to` · `transferId` · `sourceType = 'TRANSFER'` · `balanceAfterMilli = fromAfter` |
| 2 | `stockMovements/{inId}` | `create` · `TRANSFER_IN` · `signedQuantityMilli = +q` · `warehouseId = to` · `counterpartWarehouseId = from` · **same `transferId`** · `balanceAfterMilli = toAfter` |
| 3 | `stockBalances/{productId}__{from}` | `update` `onHandMilli = fromBefore − q` |
| 4 | `stockBalances/{productId}__{to}` | `set` (create if absent) `onHandMilli = toBefore + q` |
| 5 | `auditLogs/{auto}` | `create` · action `stock.transfer` · summary *"Transferred 50.000 KG of Basmati Rice from Main Store to Cold Room"* |
| 6 | `commandReceipts/{operationId}` | `create` ← **LAST** |

**`productStockSummaries/{productId}` is deliberately NOT written** (`INV-23`). A transfer cannot change
a product total, so leaving the summary untouched makes the invariant structural rather than arithmetic,
and removes the only write-contention point from the operation. `stockStatus` and `stockValueMinor`
therefore cannot change, so **no low-stock notification is possible** and none is emitted.

`transferId` is generated server-side (`db.collection(...).doc().id`), never supplied by the client.

**IDEMPOTENCY** `operationId` + `payloadHash`. A replay with the identical payload returns the stored
result and writes nothing. A replay with a different payload is rejected. **Retrying a transfer can
never move stock twice.**

**AUDIT** one record. **NOTIFICATIONS** none. **PRIVACY** intra-tenant only; no field of this command or
its result can reference another organization.

**RETURN** `{ transferId, outMovementId, inMovementId, fromOnHandMilli, toOnHandMilli }`

**DOMAIN_ERRORS**

| Code | Condition | HttpsError |
|---|---|---|
| `SAME_WAREHOUSE` | `from == to` | `invalid-argument` |
| `INVALID_QUANTITY` | `q <= 0` or precision > 3 dp | `invalid-argument` |
| `PRODUCT_NOT_ACTIVE` | product archived or missing | `failed-precondition` |
| `WAREHOUSE_NOT_ACTIVE` | either warehouse archived or missing | `failed-precondition` |
| `INSUFFICIENT_STOCK` | `fromBefore − q < 0` | `failed-precondition` |
| `CROSS_TENANT_REFERENCE` | any id resolves outside `orgId` | `permission-denied` |
| `ROLE_NOT_PERMITTED` | role ∉ `TRANSFER_WRITERS` | `permission-denied` |
| `OPERATION_REPLAYED_WITH_DIFFERENT_PAYLOAD` | hash mismatch | `failed-precondition` |

**FAILURE_GUARANTEE** All six writes commit or none does. A `TRANSFER_OUT` without its paired
`TRANSFER_IN` is impossible by construction (`INV-22`). Concurrent transfers out of the same balance
serialise on the `stockBalances` document: Firestore aborts and retries the loser, which re-reads the
new balance, so two concurrent transfers of 30 from a balance of 50 produce one success and one
`INSUFFICIENT_STOCK` — never a negative balance.

---

## 3. Stock commands C-13, C-14, C-17, C-29, C-30 — the shared shape

Every material stock change follows exactly this order (`05` §6):

```text
1  reject if unauthenticated
2  validate payload (Zod)
3  read members/{uid}; reject unless ACTIVE
4  reject unless role permitted
5  open transaction
6  READ the command receipt FIRST; short-circuit on replay, reject on hash mismatch
7  read product (must be ACTIVE) and warehouse (must be ACTIVE)
8  read the current balance and summary
9  validate quantity, unit and precision
10 compute newBalanceMilli = currentMilli + signedQuantityMilli
11 reject if negative FOR THAT WAREHOUSE          → INSUFFICIENT_STOCK
12 create the immutable StockMovement (+ balanceAfterMilli)
13 update the StockBalance
14 update the ProductStockSummary — onHand, available, stockStatus, stockValueMinor
15 update the PO line and status if this is a receipt or a dispatch
16 write the audit record
17 write notifications IF AND ONLY IF the derived stock status changed
18 create the CommandReceipt
19 commit; return a minimal result
```

**Steps 1–4 and 7 are the only authorization that exists**, because the Admin SDK bypasses rules.

**Low-stock notification** compares the status computed *before* the command with the status *after*,
inside the same transaction, and emits only on a **transition** — so receiving ten partial shipments of
a low product produces one notification, not ten (`FR-STOCK-017`).

**The negative-stock rule applies per `StockBalance`** — product × warehouse — so stock can never be
driven negative in one location and masked by a surplus in another.

### 3.1 C-13 `stock.recordOpeningBalance`
Reads: receipt, product, warehouse, balance (**must not exist or be zero**), summary.
Writes: `OPENING_BALANCE` movement (`effectiveAt` from the form, validated ≤ now), balance, summary,
audit, receipt. One opening balance per product-and-warehouse pair; a second attempt is
`failed-precondition / OPENING_BALANCE_ALREADY_RECORDED` and the UI offers an adjustment instead.

### 3.2 C-14 `stock.adjust`
Reads: receipt, product, warehouse, balance, summary.
Writes: `ADJUSTMENT_IN` or `ADJUSTMENT_OUT` (with `adjustmentReason`; `note` required when reason is
`OTHER`), balance, summary, audit, receipt, low-stock notifications **on transition only**.
A decrease exceeding 50 % of the current warehouse balance requires the confirmation state client-side;
the server does not reject it, because the minimum is a signal to buy, not a rule about reality.

### 3.3 C-17 `po.receive` (private)
Receipt quantities are in the product's **base unit** — a private supplier is not a Stockmok tenant and
there is no supplier order unit. Per line `0 < receiveMilli <= orderedMilli − receivedMilli`, else
`OVER_RECEIPT`. One `PURCHASE_RECEIPT` movement per line per receipt event, `sourceType: 'PRIVATE_PO'`,
`sourceId: poId`. PO becomes `RECEIVED` if every line is complete, otherwise `PARTIALLY_RECEIVED`.
`receivingWarehouseId` is recorded on the PO at the **first** receipt so `warehouse.archive` can detect
the open dependency. Cancellation after any receipt is `INVALID_TRANSITION`.

### 3.4 C-29 `cpo.ship` — supplier ledger only
Writes `CONNECTED_DISPATCH_OUT` movements in the **supplier** organization, supplier balances, supplier
summaries, the canonical PO → `SHIPPED`, **both** projections, history rows on all three, audit in both
organizations, a notification to the buyer, and the receipt. **The buyer's stock is untouched**
(`INV-10`, `FR-CPO-009`). There is no `PARTIALLY_SHIPPED` — the frozen single-shipment supplier model is
preserved.

### 3.5 C-30 `cpo.receive` — buyer ledger only
Receipt quantities are entered in the **supplier order unit** and converted:
`buyerBaseMilli = roundHalfUp(receiveSupplierMilli × factorMilli / 1000)`.
**Outstanding is tracked in supplier order units** to prevent conversion drift across partial receipts;
a residual rounding difference of at most one milli-unit is absorbed into the final line.
Writes `PURCHASE_RECEIPT` movements in the **buyer** organization only (`INV-11`), buyer balances, buyer
summaries, the canonical PO quantities and status, both projections, history, audit, notification,
receipt. **A buyer receipt never modifies the supplier's outbound movement.**

---

## 4. Cross-tenant commands — the two-organization write set

`connection.*` and `cpo.*` write into two tenants in one transaction. Each writes the canonical zone-4
document **and both zone-3 projections together**, which is what makes `INV-19` hold by construction.

| Command | Canonical | Buyer org | Supplier org | Both |
|---|---|---|---|---|
| `connection.request` | `connections/{id}` `txn.create` — **fails if a PENDING/ACTIVE document exists** | projection | projection | audit ×2, notification to supplier `ADMINS`, receipt |
| `connection.respond` | status → `ACTIVE`\|`REJECTED` | projection | projection | audit ×2, notification to requester, receipt |
| `connection.disable` | status → `DISABLED` | projection | projection | audit ×2, receipt |
| `cpo.draftSave` | – | buyer draft only | – | receipt |
| `cpo.submit` | canonical + items (snapshots frozen), history | projection + items + history | projection + items + history | audit ×2, notification, receipt, counter increment |
| `cpo.respond` | status, history | projection, history | projection, history | audit ×2, notification, receipt |
| `cpo.ship` | status, history | projection, history | projection, history, **movements + balances + summaries** | audit ×2, notification, receipt |
| `cpo.receive` | received quantities, status, history | projection, history, **movements + balances + summaries** | projection, history | audit ×2, notification, receipt |

Largest transaction — `cpo.ship` with five lines — writes ≈ 18 documents, far under the 500 limit.

**Connection status is re-read inside every `cpo.*` and `mapping.*` transaction**, so a connection
disabled between page load and submit is rejected rather than acted on.

---

## 5. Uniqueness and counter commands

| Command | Mechanism | Why |
|---|---|---|
| `org.create` | `txn.create(handleReservations/{handle})` | Firestore's create precondition fails if the document exists, so two concurrent requests for one handle produce exactly one winner and one `already-exists` — with no partially-created organization, because the reservation, organization, directory entry, settings, Owner membership, membership mirror, first warehouse and audit are one transaction. |
| `product.create` / `update` | `txn.create(productSkuIndex/{skuNorm})`; on a SKU change, delete the old index document and create the new one in the same transaction | A Security Rule cannot query a collection, so uniqueness cannot be enforced client-side. This makes it **race-free by database enforcement** rather than by a read-then-write check. |
| `connection.request` | deterministic id `{buyerOrgId}__{supplierOrgId}` + `txn.create` | Directional uniqueness by construction (`FR-NET-006`). A new request is permitted only when no document exists or the existing one is `REJECTED`/`DISABLED`. Self-connection is rejected. |
| `po.order`, `cpo.submit` | read + increment `counters/purchaseOrder` **inside** the transaction | Order numbers are unique under concurrency. |
| `warehouse.archive` | two `.limit(1)` queries **inside** the transaction | The Admin SDK supports query reads inside a transaction, so the "no stock, no open receipt" guard is race-free — stock added concurrently cannot slip past it. |
| `mapping.create` | `.limit(1)` duplicate check inside the transaction | No second `VERIFIED` mapping for the same buyer-product/supplier-item pair. |

---

## 6. Transaction boundary table

Each row is one atomic unit. If any write fails, none is applied.

| Command | Reads inside the transaction | Writes inside the transaction |
|---|---|---|
| `org.create` | `handleReservations/{handle}` (must not exist) | reservation, organization, directory entry, `settings/main`, Owner `members/{uid}`, `users/{uid}/memberships/{orgId}`, first warehouse, audit |
| `team.acceptInvitation` | invitation, existing membership | invitation → ACCEPTED, membership, user mirror, audit, receipt |
| `team.changeMemberRole` / `setMemberStatus` | target membership, organization (to protect the canonical Owner) | membership, user mirror, audit, notification |
| `product.create` | `productSkuIndex/{skuNorm}` (must not exist) | product, sku index, zeroed summary, audit, receipt |
| `product.update` | product, old + new sku index, summary | product, sku index delete+create if the SKU changed, summary `stockValueMinor` recomputed if the cost changed, audit |
| `product.setStatus` | product | product, summary `stockStatus`, audit |
| `warehouse.archive` | `Q-056` `limit(1)`, `Q-057` `limit(1)` | warehouse → ARCHIVED, audit |
| `stock.recordOpeningBalance` | receipt, product, warehouse, balance, summary | movement, balance, summary, audit, receipt |
| `stock.adjust` | receipt, product, warehouse, balance, summary | movement, balance, summary, audit, receipt, notifications on transition |
| **`stock.transfer`** | **receipt, product, 2 warehouses, 2 balances** | **2 movements (paired), 2 balances, audit, receipt — 6 documents; summary deliberately untouched** |
| `po.order` | receipt, PO, all items, supplier, every referenced product, counter | counter, PO (ORDERED + `orderNumber` + snapshots frozen), items, history, audit, receipt |
| `po.receive` | receipt, PO, affected items, warehouse, balances, summaries | one movement per line, balances, summaries, item quantities, PO status, history, audit, receipt, notifications |
| `connection.request` | canonical connection (must not exist or be REJECTED/DISABLED), both directory entries | canonical, both projections, audit ×2, notification, receipt |
| `connection.respond` / `disable` | canonical connection | canonical, both projections, audit ×2, notification, receipt |
| `mapping.create` | receipt, connection (ACTIVE), buyer product (ACTIVE), supplier catalog item (published), duplicate check | mapping VERIFIED, audit, receipt |
| `cpo.draftSave` | connection (ACTIVE), every mapping (VERIFIED), every product (ACTIVE) | buyer draft PO + items — **upsert, last write wins** |
| `category.archive` | **`Q-072` `limit(1)`** — ACTIVE products referencing the category | category → ARCHIVED, audit |
| `warehouse.setDefault` | `settings/main`, target warehouse (must be ACTIVE) | `settings.defaultWarehouseId`, audit |
| `cpo.submit` | receipt, buyer draft + items, connection, every mapping, every supplier catalog item, counter | canonical + items (snapshots frozen), **both** projections, history ×3, audit ×2, notification, receipt |
| `cpo.respond` | receipt, canonical PO, connection | canonical, both projections, history, audit ×2, notification, receipt |
| `cpo.ship` | receipt, canonical PO, supplier balances and summaries for every line | supplier movements, supplier balances, supplier summaries, canonical → SHIPPED, both projections, history, audit, notification, receipt |
| `cpo.receive` | receipt, canonical PO, buyer balances and summaries, warehouse | buyer movements, buyer balances, buyer summaries, canonical quantities + status, both projections, history, audit, notification, receipt |

---

## 7. Typed error model

Callables surface `HttpsError.code` and `details` to the client SDK, which is what makes the typed error
model work end to end. **A raw Firebase error code never reaches the user interface.**

| `HttpsError` code | Reason codes |
|---|---|
| `unauthenticated` | `NOT_SIGNED_IN` |
| `invalid-argument` | `SCHEMA_INVALID`, `SAME_WAREHOUSE`, `INVALID_QUANTITY`, `INVALID_FACTOR`, `SELF_CONNECTION` |
| `permission-denied` | `NOT_A_MEMBER`, `MEMBERSHIP_NOT_ACTIVE`, `ROLE_NOT_PERMITTED`, `CROSS_TENANT_REFERENCE`, `OWNER_PROTECTED`, `INVITE_EMAIL_MISMATCH` |
| `failed-precondition` | `INVALID_TRANSITION`, `INSUFFICIENT_STOCK`, `OVER_RECEIPT`, `PRODUCT_NOT_ACTIVE`, `WAREHOUSE_NOT_ACTIVE`, `WAREHOUSE_HAS_STOCK`, `WAREHOUSE_HAS_OPEN_RECEIPT`, `OPENING_BALANCE_ALREADY_RECORDED`, `CONNECTION_NOT_ACTIVE`, `CATALOG_ITEM_NOT_PUBLISHED`, `MAPPING_EXISTS`, `SEMANTIC_NOT_CONFIRMED`, `INVITE_EXPIRED`, `INVITE_NOT_PENDING`, `OPERATION_REPLAYED_WITH_DIFFERENT_PAYLOAD` |
| `already-exists` | `HANDLE_TAKEN`, `SKU_TAKEN`, `CONNECTION_EXISTS` |
| `not-found` | `RESOURCE_NOT_FOUND`, `INVITE_UNKNOWN`, `SKU_NOT_FOUND` |
| `resource-exhausted` | `NOTIFICATION_FANOUT_EXCEEDED` (logged, command still succeeds) |

---

## 8. Cost and abuse guardrails

`maxInstances: 10` on every function · 256 MiB / 60 s · authenticated-only, no unauthenticated write path
anywhere · every in-transaction query bounded · notification fan-out capped at 50 · no App Check in A/B
(documented next step; every callable still enforces membership and role, so the blast radius of a stolen
ID token is limited to what that user could already do in the UI).

**Cold starts** of 1–3 s are expected on the first call after idle. Submitting controls stay disabled for
the duration; the demo is preceded by a warm-up script rather than paid `minInstances`.

---

## 9. Contract result

```
COMMAND_COVERAGE      = 100%   (36 commands; every UI mutation maps to exactly one)
TRANSACTION_COVERAGE  = 100%   (every multi-document invariant inside one transaction)
IDEMPOTENT_COMMANDS   = 13     (all stock-, receipt- and cross-tenant-affecting commands)
HTTP_ENDPOINTS        = 0
FIRESTORE_TRIGGERS    = 0
PARTIAL_STATE_PATHS   = 0
```
