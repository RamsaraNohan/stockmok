# DB-03 — FINAL UI → DATA TRACEABILITY MATRIX

**Status:** FROZEN. Every approved Release A + B-Lite surface mapped to its reads, queries, writes,
mutation class, commands, states, permissions and indexes.
**Surface authority:** the immutable registries `18` (`SCREEN/STATE`), `19` (`FORM`/`TABLE`, routes),
`22` (`ACTION`/`FIELD`), `23` (access matrix), plus amendment A1 (`SCREEN-053`, `FORM-024`,
`ACTION-062`, `STATE-044`).
**Query IDs** are defined in DB-04. **Commands** are defined in DB-06.

```
SURFACES          = 53   (52 frozen + SCREEN-053 Stock Transfer, per A1)
UI_DATA_COVERAGE  = 100%
```

## 0. Reading this matrix

- **Mutation class** is either `SAFE_DIRECT_CLIENT_WRITE` (one of the six rules-guarded surfaces) or
  `TRUSTED_COMMAND_ONLY`. There is no third class. The classification here, in DB-05 and in DB-06 is
  identical by construction.
- **Realtime.** Firestore `onSnapshot` is used on exactly four surfaces (§4). Everything else is a
  one-shot request through TanStack Query. This is a cost and correctness decision, not an oversight:
  a listener on a paginated list re-bills the whole page on every unrelated write.
- **Roles** use `06` §5 / `23` §3 verbatim: `O` Owner · `A` Admin · `IM` Inventory Manager ·
  `PM` Procurement Manager · `SK` Storekeeper · `AN` Analyst · `V` Viewer.
- **Base states** per `19` §1: `Base-D` = loading + error + permission-denied; `Base-L` = `Base-D` +
  empty; `Base-F` = validation + submitting; `Base-M` = success; `Base-X` = confirmation.
- Every organization-scoped surface additionally inherits `SCREEN-008` shell reads `Q-006`, `Q-008`,
  `Q-005`.
- Every list is bounded: page size **25**, hard maximum **100**, cursor `startAfter`, never offset.

---

## 1. Public, authentication and organization entry

| Surface | Roles | Reads (Q) | Displayed data | Filters / sort / page | RT | Writes · class · command | States | Indexes |
|---|---|---|---|---|:-:|---|---|---|
| **001** Public Home | anyone | none | static marketing only | – | – | none | `STATE-001/003` | – |
| **002** Sign Up | anyone | none | – | – | – | Firebase Auth `createUser`; then `users/{uid}` `setDoc(merge)` · **SAFE_DIRECT_CLIENT_WRITE** | Base-F + `004` | – |
| **003** Global Login | anyone | `Q-003` after auth | membership count only | – | – | Auth only; `lastSeenAt` · **SAFE_DIRECT_CLIENT_WRITE** | Base-F + `004`, `STATE-012` | – |
| **004** Branded Login | anyone | **`Q-001`** (public `get` by handle, pre-auth) | monogram, name, `@handle`, industry, country | – | – | Auth only | **`STATE-009…016` all required** | – |
| **005** Invitation Accept | invitee | `Q-001`; invitation resolved **server-side by token** — never a client read | org identity, offered role, expiry | – | – | `team.acceptInvitation` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + `040/041` | – |
| **006** Workspace Selector | auth | `Q-003` | monogram, full name, `@handle`, role — **ACTIVE mirrors only** | none; small set | – | none | Base-L/D | – |
| **007** Onboarding | auth, 0 memberships | `Q-001` advisory availability `get` | – | – | – | `org.create` · **TRUSTED_COMMAND_ONLY** | Base-F/M + `017…020` | – |
| **008** App Shell | all | `Q-006`, `Q-007`, `Q-008`, `Q-005`, `Q-003` | org identity, role badge, unread count | – | **✔** `Q-008`, `Q-005` | none | Base-D + `016` | `IDX-17` |
| **029** Permission Denied | all | none — **executes no page query** | requested area, current role, required role | – | – | none | `STATE-006` | – |
| **030** 404 | all | none | neutral copy | – | – | none | `STATE-036` | – |
| **041** Password Reset | anyone | none | – | – | – | Auth `sendPasswordResetEmail` | Base-F/M | – |
| **043** Mobile Navigation | all | inherits shell | role/flag-filtered nav | – | – | none | Base-D | – |
| **052** Notification Menu | all | `Q-004` `limit(5)`, `Q-005` | 5 latest + unread count | unread/all | **✔** `Q-005` | `notification.markRead` · **SAFE_DIRECT_CLIENT_WRITE** (`read` only) | Base-L/M | `IDX-17` |

`Q-001` is a document **`get`**, never a query. `list` on `organizationDirectory` is denied, which is
what stops a visitor enumerating every business on the platform. Resolving a handle grants nothing.

---

## 2. Dashboard and inventory

| Surface | Roles | Reads (Q) | Displayed data | Filters / sort / page | RT | Writes · class · command | States | Indexes |
|---|---|---|---|---|:-:|---|---|---|
| **009** Empty Dashboard | all | `Q-050` | zero-state checklist, role-filtered | – | – | none | `STATE-043`, Base-D | `IDX-01` |
| **010** Populated Dashboard | all | `Q-053` value · `Q-050` SKUs · `Q-051` low · `Q-052` out · `Q-054` open POs · `Q-055` awaiting · `Q-063` activity · `Q-021` low list · `Q-033` recent POs · `Q-060` by location · B: `Q-064`, `Q-065` | 5 KPIs, Needs Attention, `TABLE-024…027`, `CHART-001/002` | per-panel; no pagination | – | none — **no manually editable KPI document exists** | Base-D, per-panel loading/error | `IDX-01/04/11/13`, `stockValueMinor` |
| **044–047** Dashboard role variants | O/A, IM, PM, SK | subset of the above by capability | role-appropriate panels only | – | – | none | Base-D | as above |
| **011** Product List | all read; O/A/IM act | **`Q-011`/`Q-012`/`Q-013`/`Q-013b`/`Q-015` — all served entirely from `productStockSummaries` (DB-CR-011), 25 reads, no join** | `TABLE-001`: name, SKU, category, on hand + unit, status pill, preferred supplier, updated | search; category, stock status, warehouse, archived. Sort **name, SKU, updated, on hand only** | – | `product.setStatus` · **TRUSTED_COMMAND_ONLY** | Base-L/D/M/X | `IDX-01/02/03/04` |
| **012** Product Create / Edit | O/A/IM (others DENIED) | `Q-014`, `Q-016` | `FORM-006` | – | – | `product.create`, `product.update` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M/X | – |
| **013** Product Detail | all read | `Q-014`, `Q-020`, `Q-018` (Stock tab), `Q-023` `limit(5)`, `Q-048` (Activity), B: `Q-044` | overview fields, per-warehouse `TABLE-004`, recent `TABLE-005`, mappings | tab-scoped | – | `product.setStatus`; opens `016`, `042`, **`053`** | Base-D + per-tab | `IDX-09/05/18/15` |
| **014** Categories | O/A/IM | `Q-016` | `TABLE-002` | search, status; sort name/updated | – | create/update · **SAFE_DIRECT_CLIENT_WRITE**; **`category.archive` / `restore` · TRUSTED_COMMAND_ONLY** | Base-L/D/F/M/X + archive-blocked | `IDX-28`, `IDX-38` |
| **015** Warehouses | O/A/IM | `Q-017`; on archive click `Q-058` for the blocking detail | `TABLE-003` | search, type/status | – | create/update · **SAFE_DIRECT_CLIENT_WRITE**; `warehouse.archive`, **`warehouse.setDefault`** · **TRUSTED_COMMAND_ONLY**; opens **`053`** | Base-L/D/F/M/X + `STATE-035` | `IDX-08` |
| **016** Stock Adjustment *(modal)* | O/A/IM | `Q-014`, `Q-017`, `Q-018` | current → change → result, live | – | – | `stock.adjust` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + X (>50 %) + `STATE-037` | – |
| **042** Opening Balance *(dialog)* | O/A/IM | `Q-014`, `Q-017`, `Q-018` (must be absent/zero) | product, store room, quantity, `effectiveAt` | – | – | `stock.recordOpeningBalance` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + `STATE-037` | – |
| **053** **Stock Transfer** *(modal — A1)* | **O/A/IM** | `Q-014`, `Q-017`, `Q-018` **×2** (source and destination balances) | From ▾, To ▾, Product ▾, Quantity; source-after, destination-after, **total unchanged** | – | – | **`stock.transfer` · TRUSTED_COMMAND_ONLY** | Base-D/F/M + **`STATE-044`** (same store room) + `STATE-037` (replay) + X (>50 % source reduction) | `IDX-09` |
| **017** Movement History | all except V (**V DENIED**) | `Q-022` … `Q-029` by filter combination | `TABLE-006`: time, product, SKU, warehouse, kind, signed qty + unit, **balance after**, actor, reference | search; date range, product, warehouse, **Kind**. Sort **time only** | – | **none — immutable, no row actions** | Base-L/D | `IDX-05/06/07`, **`IDX-20…24`** |

**`TABLE-006` Kind filter** is implemented per DB-02 §0.2: five equality predicates and one `in` of two
values. No discriminator column exists. **Balance After** is `stockMovements.balanceAfterMilli`
(DB-CR-006) — it cannot be computed from a filtered, paginated page and is therefore persisted.

---

## 3. Private partners, procurement, reports, administration

| Surface | Roles | Reads (Q) | Displayed data | Filters / sort / page | RT | Writes · class · command | States | Indexes |
|---|---|---|---|---|:-:|---|---|---|
| **018** Suppliers | O/A/PM | `Q-031` | `TABLE-007`, tabs Private/Connected/Pending | tabs, search, status | – | create/update/deactivate · **SAFE_DIRECT_CLIENT_WRITE** | Base-L/D/F/M/X | `IDX-10` |
| **019** Buyers | O/A/PM | `Q-031` (BUYER) | `TABLE-007` — **directory only, no sales affordance** | as above | – | as above | as above | `IDX-10` |
| **020** Partner Detail | O/A/PM | `Q-032`, `Q-039`, `Q-040`; connected: `Q-042` | contact, status, `TABLE-008/009` | partner-scoped | – | update/deactivate · **SAFE_DIRECT_CLIENT_WRITE** | Base-D/L/M/X | `IDX-11` |
| **021** PO List | O/A/PM full; IM/SK/AN read; **V DENIED** | `Q-033`, `Q-034` | `TABLE-010` | tabs Private/Connected; search, status, date, kind. Sort created, expected, number, total | – | opens `022`/`038` | Base-L/D/M | `IDX-11/12` |
| **022** PO Builder | O/A/PM | `Q-031`, `Q-011`, `Q-014` | `FORM-011`, 4-step | – | – | DRAFT create/update · **SAFE_DIRECT_CLIENT_WRITE**; `po.order` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + `039` | `IDX-01/10` |
| **023** PO Detail | O/A/PM full; IM/AN read; SK limited; **V DENIED** | `Q-036`, `Q-037`, `Q-038` | header, `TABLE-011`, totals, timeline | – | – | `po.order`, `po.cancel` · **TRUSTED_COMMAND_ONLY** | Base-D/M/X + `039` | – |
| **024** Private Receiving | O/A/IM/PM/SK | `Q-035`, `Q-036`, `Q-037`, `Q-017`, `Q-018` | `TABLE-012`, current/after/outstanding | eligible POs only | – | `po.receive` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + `037/038` | `IDX-13` |
| **025** Reports Shell | tab-gated | none at shell | tabs only | – | – | none | Base-D | – |
| **048** Stock-on-Hand Report | **all seven** | `Q-061` | `TABLE-013`: product, warehouse, on hand, unit, status, value | warehouse, category, status; sort product, warehouse, on hand, value; CSV | – | CSV export of **already-fetched authorized rows only** | Base-L/D/M | `IDX-08/09/04` |
| **049** Purchase-Order Report | O/A/IM/PM/AN; **SK, V DENIED** | `Q-062` | `TABLE-014` | status, date range, kind; CSV | – | CSV export | Base-L/D/M | `IDX-11/12` |
| **026** Notifications | all | `Q-004`, `Q-005` | `TABLE-015` | all/unread; type; newest first; cursor | **✔** `Q-005` | `read` flag · **SAFE_DIRECT_CLIENT_WRITE** | Base-L/D/M | `IDX-17` |
| **027** Team | O full; A limited; others DENIED | `Q-009`, `Q-010` | `TABLE-016/017`, protected Owner row | search, role/status | – | `team.createInvitation`, `revokeInvitation`, `changeMemberRole`, `setMemberStatus` · **TRUSTED_COMMAND_ONLY** | Base-L/D/F/M/X + `042` | `role, status` |
| **050** Invitation Link *(modal)* | O; A limited | none — **the raw token is in the command result only, never re-read** | link once, expiry, email, role | – | – | none | `STATE-042` | – |
| **028** Settings | O full; A limited; others DENIED | `Q-006`, `Q-007`, `Q-017` | `FORM-015` | – | – | `org.updateSettings` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M/X | – |

---

## 4. Release B-Lite — network and connected procurement

All of `031…040` require `settings.networkEnabled`. When false the navigation is absent and a direct
route renders authenticated `SCREEN-030` (`STATE-036`) — **not** a permission denial, because it is not
a role decision.

| Surface | Roles | Reads (Q) | Displayed data | Filters / sort / page | RT | Writes · class · command | States | Indexes |
|---|---|---|---|---|:-:|---|---|---|
| **031** Connected Businesses | O/A full; PM limited | `Q-041` | `TABLE-018` | incoming/outgoing/status; newest first | – | `connection.respond` (O/A/PM); **`connection.disable` O/A only** · **TRUSTED_COMMAND_ONLY** | Base-L/D/M/X | `IDX-14` |
| **032** Business Discovery *(panel)* | O/A/PM | **`Q-001`** exact `get` | monogram, name, `@handle`, industry, country — **nothing else** | exact handle only; **no list, no prefix, no fuzzy** | – | `connection.request` · **TRUSTED_COMMAND_ONLY** | `STATE-021…027` | – |
| **033** Connection Detail | O/A full; PM limited | `Q-042`, `Q-043`, `Q-034` | identity, status, `TABLE-019/020` | connection-scoped | – | `connection.respond`, `connection.disable` | Base-D/L/M/X | `IDX-15/12` |
| **034** Partner Catalog — supplier | O/A/PM | `Q-045` | `TABLE-021` — **no stock, no cost** | search, published/availability | – | `partnerCatalog.publish` / `unpublish` · **TRUSTED_COMMAND_ONLY** | Base-L/D/M/X | `IDX-16` |
| **035** Partner Catalog — buyer browse | O/A/PM read | **`Q-046` callable only** | `TABLE-022`, labelled *"partner projection, not supplier inventory"* | bounded set returned by the callable | – | none | Base-L/D | supplier-side `IDX-16` |
| **036** Mapping Wizard | O/A/PM | `Q-041`, `Q-011`, **`Q-047` callable** | side-by-side cards, worked preview `10 PACK = 50 KG` | – | – | `mapping.create` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + **`STATE-028…034` all seven** | `IDX-16/01` |
| **037** Mappings List | O/A/PM | `Q-043` | `TABLE-023` | supplier/status; sort verified time | – | `mapping.disable` · **TRUSTED_COMMAND_ONLY** | Base-L/D/M/X | `IDX-15` |
| **038** Connected PO — buyer | O/A/PM full; IM/SK/AN read; **V DENIED** | `Q-036`, `Q-037`, `Q-038`, `Q-043` | dual representation, timeline | – | – | DRAFT edit · **SAFE_DIRECT_CLIENT_WRITE**? **NO — see note** ; `cpo.submit`, `cpo.cancel` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M/X + `039` | `IDX-12` |
| **039** Connected PO — supplier | same matrix | `Q-036`, `Q-037`, `Q-038` | supplier projection, **no buyer-private data** | – | – | `cpo.respond`, `cpo.ship` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M/X + `037/039` | `IDX-12` |
| **040** Connected Receiving | O/A/IM/PM/SK | `Q-036`, `Q-037`, `Q-017`, `Q-018` | supplier-unit input, live base conversion, outstanding | – | – | `cpo.receive` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M + `037/038` | – |
| **051** Publish Partner Item *(dialog)* | O/A/PM | `Q-014`, `Q-045` | `FORM-019`; `orderUnit` **locked** to base unit | – | – | `partnerCatalog.publish` · **TRUSTED_COMMAND_ONLY** | Base-D/F/M/X | – |

> **Note on the connected DRAFT (SCREEN-038).** The rules-guarded client write path is permitted **only
> while `supplierKind == 'PRIVATE'`**. A connected draft therefore has `supplierKind == 'CONNECTED'` from
> creation and is **`TRUSTED_COMMAND_ONLY`** throughout — `cpo.draftSave` (C-34) covers create and edit.
> This closes a gap that a naive reading of `11` §9.3 leaves open: without it, a buyer could create a
> connected draft client-side with a forged `counterpartyOrgId`. The draft still lives only in the
> buyer's tenant and remains invisible to the supplier until `cpo.submit` (`FR-CPO-015`).

---

## 5. Realtime listeners — the complete list

Exactly four `onSnapshot` subscriptions exist. Everything else is a one-shot request.

| # | Path | Surface | Why realtime is required |
|---|---|---|---|
| RT-1 | `organizations/{orgId}/members/{uid}` | `008` shell | A suspended member must lose the workspace without a refresh (`06` §16, `SC-20`). One document. |
| RT-2 | `users/{uid}/notifications` where `read == false` — **count only** | `008`, `026`, `052` | The unread badge must move on its own. Bounded by `IDX-17` and `limit(50)`. |
| RT-3 | `organizations/{orgId}/purchaseOrders/{poId}` | `023`, `038`, `039` | Both parties watch one shared order transition. One document, open only while the detail page is mounted. |
| RT-4 | `organizations/{orgId}/connections/{connectionId}` | `033` | A connection may be accepted or disabled by the counterparty while the page is open — this is what makes `ATTACK-09` visible to the user rather than only rejected at submit. |

**No list surface is a listener.** A listener over a 25-row page re-bills the page on every unrelated
write in the collection, and none of the frozen list surfaces claims live behaviour.

---

## 6. Mutation classification — complete

Every mutation discoverable from the frozen UI and use cases, classified once. DB-05 and DB-06 restate
this identically.

**`SAFE_DIRECT_CLIENT_WRITE` — six surfaces, nothing else**

| Mutation | Path | Guard |
|---|---|---|
| Update own profile | `users/{uid}` | self; `displayName`, `photoUrl`, `lastSeenAt` only |
| Mark notification read | `users/{uid}/notifications/{id}` | self; `onlyChanged(['read'])` |
| Create / update Category (**not `status`**) | `…/categories/**` | `INVENTORY_WRITERS`; validated shape. Archive/restore is `C-35` (DB-CR-012) |
| Create / update Warehouse (**not `status`**) | `…/warehouses/**` | `INVENTORY_WRITERS`. Archive is `C-12`; setting the default is `C-36` (DB-CR-013) |
| Create / update / deactivate Private Partner | `…/privatePartners/**` | `PARTNER_WRITERS` |
| Create / update **private DRAFT** PO and items | `…/purchaseOrders/{poId}` | `PO_WRITERS`; `supplierKind == 'PRIVATE'` **and** `status == 'DRAFT'`; draft fields only |

**`TRUSTED_COMMAND_ONLY` — everything else**, without exception: organization creation and handle
reservation · every membership and invitation change · product create/update/archive/restore ·
**warehouse archive** · opening balance · stock adjustment · **stock transfer** · every purchase-order
transition and receipt · connection request/response/disable · partner-catalog publish/unpublish/list/
lookup · mapping create/disable · every connected-PO transition including the connected draft · all
audit creation · all notification creation.

**No client delete exists anywhere.** `INV-21`.

---

## 7. Coverage reconciliation

| Check | Result |
|---|---|
| Frozen surfaces `SCREEN-001…052` mapped | 52 / 52 |
| Amendment surface `SCREEN-053` mapped | 1 / 1 |
| Surfaces with at least one read or an explicit "no read" | 53 / 53 |
| Surfaces with every write classified | 53 / 53 |
| `FORM-001…024` with a target command or client path | 24 / 24 |
| `TABLE-001…027` with a query id, filter set, sort set and page contract | 27 / 27 |
| `ACTION-001…062` with an outcome and a data path | **62 / 62 — enumerated one by one in DB-10 §3** |
| Responsive variants where data behaviour changes | none — R2 changes layout only, never the query |
| Release B-PLUS / C / D surfaces mapped | 0 — correctly absent |
| **`UI_DATA_COVERAGE`** | **100 %** |
