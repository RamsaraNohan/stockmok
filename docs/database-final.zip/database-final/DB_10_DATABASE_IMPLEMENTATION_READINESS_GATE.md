# DB-10 — DATABASE IMPLEMENTATION READINESS GATE

**Status:** adversarial. This gate exists to **break** DB-01 → DB-09, not to bless them.
**Rule:** no conditional pass. The verdict is `YES` or `NO`.

---

## 1. Independent review — what actually happened

```
INDEPENDENT_REVIEWER_AVAILABLE = NO
```

Three independent reviewer subagents were dispatched — one for security/RBAC/tenant isolation, one for
Firestore feasibility and query/index compatibility, one for coverage/seed/scope leakage. **All three
terminated before returning findings** ("You've hit your org's monthly spend limit"). No usable review
output was recovered. This is recorded rather than hidden, and it is the single largest quality caveat
on this pack.

Per §18 of the run instruction, a **fresh adversarial second pass** was performed by the primary agent
instead. That pass was not a re-read: it attacked the pack's own arithmetic and its Firestore claims from
scratch, and it **found five substantive defects, all of which are now corrected** in DB-00 → DB-09.

| # | Defect found in the second pass | Severity | Resolution |
|---|---|---|---|
| DB-CR-011 | The product list read 25 `products` then joined 25 summaries by `documentId() in [...]`, claiming ≈26 reads. **An `in` query still bills one read per returned document**, so the page cost **50 reads** against the frozen `NFR-017` budget of 27. Batching reduces round trips, not billing. | **HIGH** | `TABLE-001` is now served entirely from `productStockSummaries`, which carries denormalised product display fields written in the same transaction that already writes the summary. **25 reads.** New `DV-10`, new indexes `IDX-33…IDX-37`. |
| DB-CR-012 | Category archive is blocked in the frozen design *"by physical truth rather than by permission"* — no ACTIVE product may reference the category. That is an unbounded query. `06` §6.1 nevertheless listed categories as fully client-writable, so the guard was **unenforceable**. | **HIGH** | `C-35 category.archive` / `category.restore` with a `limit(1)` guard inside the transaction; rules now deny a client setting `status`. Index `IDX-38`. |
| DB-CR-013 | `warehouse.isDefault` and `settings.defaultWarehouseId` were two sources of one truth. "Exactly one is true" is not expressible in a Security Rule, and switching it is inherently a two-document write. | MEDIUM | The `isDefault` field is **deleted from the schema**. `settings.defaultWarehouseId` is the sole source of truth; the frozen *"Make this the default store room"* control is `C-36 warehouse.setDefault`. |
| DB-CR-014 | `cpo.draftSave` was specified as idempotent with a `commandReceipt`. Receipts are never deleted in A/B, so every draft save would leave a permanent document — unbounded growth from ordinary editing. | MEDIUM | Not idempotent, no receipt, no audit. A draft save is an upsert and is idempotent by nature; it keeps its transaction only to re-validate connection, mappings and products. |
| — | The dashboard "9 reads" claim silently deferred Needs Attention, which the frozen design places above the fold. | LOW | Replaced with an itemised table: **11 reads on a warm shell, 14 cold**, and marked an **obligation to measure at Stage 17** rather than a proven claim. Also recorded: while a search term is active the sort is forced to the searched field, because Firestore requires the first `orderBy` to be the range field. |

**Residual risk from the missing independent review, stated plainly.** A single author verifying their
own work catches arithmetic and contradiction well and blind spots poorly. The highest-risk unverified
areas are (a) exhaustive per-cell RBAC agreement between DB-05 and file `06` §5, and (b) whether any
`TABLE-001…027` filter combination still lacks an index. **Recommendation: re-run the three reviewers
when budget allows, before Codex begins.** This does not block the pack, because every claim below is
traceable to a quoted authority, but it is the first thing to redo.

---

## 2. Blocker disposition

| Blocker | Status |
|---|---|
| **DB-B-02 / DB-CR-004** inter-warehouse Transfer | **CLOSED** by owner decision, 2026-08-15. Recorded in DB-00 as amendment A1. |
| **DB-B-01** design artifact manifest is wrong | **DOWNGRADED to a required non-database repair.** Resolved *for this pack* by evidence: every rival pair is disambiguated deterministically from the change register plus content markers (DB-00 §5), and the residual stale content is provably non-database (a handle spelling, a mobile-nav pattern, a reconnect wording — all already authoritatively resolved in the change register). **The manifest itself is still factually wrong and must be corrected** before frontend implementation trusts it. |

---

## 3. `ACTION-001 … ACTION-062` — every action has legitimate backend behaviour

The single most important check in this gate: **can any frozen UI action reach the database with no
defined behaviour?** Enumerated rather than asserted.

| Actions | Backing |
|---|---|
| 001, 005, 007, 008, 009, 018, 021, 043, 052, 054, 055 | navigation / UI only — no data path required |
| 002, 003, 004, 053, 061 | Firebase Auth |
| 006 | `C-01 org.create` |
| 010 | `C-09` / `C-10` |
| 011 | `C-11 product.setStatus` |
| 012, 014 | client write — categories / warehouses |
| **013** | **`C-35 category.archive`** ← was a client `status` write; corrected in the second pass |
| 015 | `C-12 warehouse.archive` |
| 016 | `C-13` |
| 017 | `C-14` |
| 019, 020 | client write — private partners |
| 022 | client write (private DRAFT) · **`C-34 cpo.draftSave`** (connected DRAFT) ← gap closed by DB-CR-010 |
| 023 | `C-15 po.order` |
| 024 | `C-16` / `C-31` |
| 025 | `C-17` / `C-30` |
| 026 | client-side CSV of the already-fetched authorized page — no query |
| 027 | client write, `read` flag only |
| **028** *(Mark all read)* | client batch of ≤ 25 `read` updates — **bounded to the loaded page**, not the whole collection |
| 029 | `C-04` · 030 clipboard · 031 `C-07` · 032, 033 `C-08` |
| 034, 035 | `C-02 org.updateSettings` |
| 036 | `Q-001` public `get` |
| 037 `C-18` · 038, 039 `C-19` · 040 `C-20` |
| 041 `C-21` · 042 `C-22` · 044 `C-24` · 045 `C-25` · 046 `C-26` |
| 047 `C-27` · 048, 049 `C-28` · 050 `C-29` |
| 051 *(Retry)* | re-invocation carrying the **same `operationId`** |
| 056, 057, 058, 059 | query / cursor — no mutation |
| 060 | `C-06 team.acceptInvitation` |
| **062** *(A1)* | **`C-33 stock.transfer`** |

**Result: 62 / 62. No frozen UI action lacks backend behaviour.** Two actions (013, 022-connected) had
none when the pack was first drafted; both are now closed.

Additionally: a frozen surface requiring data the schema did not provide — `TABLE-005`/`TABLE-006`
**Balance After** — was closed by `balanceAfterMilli` (DB-CR-006), and the six-word ledger Kind filter was
closed by the derived mapping in DB-02 §0.2 with **no schema cost**.

---

## 4. Attack review

| ID | Attack | Entry point | Resource | Expected | Enforcement layer | Rule / function / transaction | Test |
|---|---|---|---|---|---|---|---|
| **01** | Org A reads Org B private data | client SDK, forged path | `organizations/B/**` | **DENY** | Rules | `isActiveMember(B)` false — the membership document does not exist on the constant path | T-SEC-02/03 |
| **02** | Connected buyer reads supplier warehouses | client SDK | `organizations/S/warehouses` | **DENY** | Rules | `CONN` has no rule-level privilege anywhere; it is an ordinary non-member | T-SEC-10 |
| **03** | Connected buyer reads supplier private cost | callable | `partnerCatalog.list` | **allowed fields only** | Command | allow-listed projection; cost, stock, margin and warehouse are never copied into it | T-SEC-10/16 |
| **04** | Lower role invokes a privileged command | callable | any | **DENY** | Command step 5 | role read **from the membership document**, never `request.data.role` | T-SEC-05/06, **T-SEC-24** |
| **05** | Suspended member uses an existing session | client + callable | everything | **DENY at both layers** | Rules + command | `isActiveMember()` requires `ACTIVE`; every command re-reads membership at request time | T-SEC-07 |
| **06** | Client substitutes `organizationId` | callable payload | another tenant | **DENY** | Command step 3+6 | `orgId` is a routing hint; the membership read turns it into a fact or a denial | T-SEC-14 |
| **07** | Duplicate receiving `operationId` | callable retry | stock | **stored result, no second effect** | Transaction | receipt read as the **first** read *inside* the transaction | T-SEC-15, SC-22 |
| **08** | Concurrent receive of the same outstanding quantity | two callables | PO + stock | one success, one `OVER_RECEIPT` | Transaction | both serialise on the PO document; the loser re-reads `receivedMilli` | T-CONC-04 |
| **09** | Connection disabled during a mapping workflow | callable | mapping | **DENY** | Command | connection status **re-read inside** the transaction, not at page load | T-SEC-13, `STATE-033` |
| **10** | Connected PO uses a stale or invalid mapping | callable | `cpo.submit` | **DENY** | Command | every mapping re-validated `VERIFIED` + connection ACTIVE inside the transaction | T-CPO-* |
| **11** | Illegal PO transition | callable | PO | **DENY** | Command step 7 | one shared transition table (DB-07 §8/§9); absent transition = forbidden | T-PPO-*, T-CPO-* |
| **12** | Invitation token guessed or reused | public route + callable | invitation | **DENY** | Command | 32 random bytes, only the SHA-256 hash stored, single-use, 7-day expiry, email-bound | SC-03 |
| **13** | Business discovery beyond exact lookup | client SDK | `organizationDirectory` | **`list` DENY** | Rules | `allow get: if true; allow list: if false` | T-SEC-20 |
| **14** | Client writes a fake audit record | client SDK | `auditLogs` | **DENY** | Rules | `create`, `update`, `delete` denied to every client **including the Owner** | T-SEC-08/09 |
| **15** | Client changes `stockBalance` without a command | client SDK | `stockBalances` | **DENY** | Rules | backend-write-only for every role | T-SEC-04 |
| **16** *(A1)* | **Transfer names a warehouse in another organization** | callable | `stockBalances` in Org B | **DENY** | Command step 6 | both warehouses re-read under `organizations/{verifiedOrgId}/`; a foreign id resolves to a missing document, never to another tenant's data | **T-XFER-11** |
| **17** *(A1)* | **Transfer to the same warehouse to mint a phantom movement pair** | callable | ledger | **DENY** | Command precondition 1 | `from != to`; nothing written | **T-XFER-05**, `STATE-044` |
| **18** *(A1)* | **Transfer replayed to duplicate stock** | callable retry | ledger | **stored result, no second pair** | Transaction | `operationId` + `payloadHash` | **T-XFER-08/09** |
| **19** *(A1)* | **Two concurrent transfers drain a balance negative** | two callables | `stockBalances` | one success, one `INSUFFICIENT_STOCK` | Transaction | both serialise on the source balance; the loser re-reads and fails the guard | **T-CONC-07** |
| **20** *(A1)* | **Storekeeper relocates stock to hide a shortage** | callable | ledger | **DENY** | Command step 5 | `TRANSFER_WRITERS` excludes Storekeeper — the segregation-of-duties control that already excludes them from adjustment | **T-XFER-12**, T-SEC-24 |

---

## 5. Verification against the gate checklist

| Check | Result | Basis |
|---|---|---|
| Every final frontend surface has data support | **PASS** | DB-03 — 53/53 |
| Every UI action has legitimate backend behaviour | **PASS** | §3 — 62/62, two gaps closed |
| Every query is physically implementable | **PASS** | DB-04 §1–§6 |
| Every query has an index strategy | **PASS** | DB-04 §7 — 38 composite + automatic single-field |
| Rules / query compatibility | **PASS** | every client query is single-tenant-path scoped; no rule reads a data-derived path |
| Pagination feasibility | **PASS** | cursor, 25 / 100, on every list without exception |
| No forbidden cross-tenant scan | **PASS** | zero cross-tenant client queries; zero collection-group queries |
| Sensitive commands have explicit authorization | **PASS** | DB-06 §0 — nine-step frame, implemented once |
| All stock mutations are atomic | **PASS** | DB-06 §6 |
| Every stock change creates a movement | **PASS** | a balance is never written without its movement |
| Retries are idempotent | **PASS** | receipt first-read / last-write, payload hash |
| Concurrent receiving is safe | **PASS** | T-CONC-04; outstanding re-read inside the transaction |
| **Concurrent transferring is safe** | **PASS** | T-CONC-07/08 |
| State transitions cannot be bypassed | **PASS** | one shared transition table; absent = forbidden |
| Mapping races are handled | **PASS** | connection, publication and product re-validated inside the transaction |
| Connected privacy holds | **PASS** | projections + connection-verified callables; `CONN` has no rule privilege |
| Invitations are secure | **PASS** | hash-only, single-use, expiring, email-bound |
| Fake audit / balance writes fail | **PASS** | T-SEC-04/08/09 |
| Derived data has a consistency strategy | **PASS** | DB-07 §12 — DV-01…DV-10, all atomic with source |
| Canonical seed reconciles | **PASS** | DB-08 §9 — 12 / 4 / 1 / LKR 564,200.00 → 691,700.00 / 17 movements |
| Firestore feasibility holds | **PASS** | with the four second-pass corrections applied |
| No Release C / D leakage | **PASS** | §6 |
| No implementation agent must invent behaviour | **PASS** | every open decision is either specified or listed in DB-09 §11 as a stop condition |

## 6. Scope-leakage sweep

Checked against `03` §5 and §6. **Not present anywhere in the pack:** sales or outbound subsystem ·
storefront / checkout / POS · reservation (`reservedMilli` is constant 0 and no command writes it) ·
transfer approval or in-transit state · multi-product transfer · cross-organization transfer · multiple
or partial shipments (`PARTIALLY_SHIPPED` does not exist) · batch / lot / expiry · serial numbers ·
weighted-average costing · multi-currency purchase orders · App Check · Cloud Storage · error-monitoring
service · email delivery · file uploads · full-text search · custom roles · owner transfer or multi-owner
governance · dedicated database per tenant · webhooks or event buses · automatic reorder · AI forecasting
· distributed counters · a scheduled reconciliation job · **an audit-log route** (ACR-001 resolved as the
documented default — audit surfaces only inside per-object Activity).

`storefrontCatalog` and `C-32` are declared **inert and not built**, present solely so no agent
reintroduces them by accident.

## 7. Open items — non-blocking, but real

| # | Item | Owner | When |
|---|---|---|---|
| 1 | **Correct `STOCKMOK_FINAL_DESIGN_ARTIFACT_MANIFEST.md`** — re-hash every artifact; invert the Gate 6/7/9 supersession; locate the patched Gate 5/8/10/11/12 files or record the local copies as pre-patch | Owner / design | before frontend implementation |
| 2 | **Blaze billing** — `ADM-009` is still unmade; production Cloud Functions cannot deploy on Spark. Recommend Blaze + $5 budget + 50/90/100 % alerts + `maxInstances: 10`. If refused, apply the `03` §8 P0 contingency and cut Release B | Owner | Day 1 of implementation |
| 3 | Functions region — recommend `asia-southeast1` to co-locate with Firestore | Implementation | at `firebase init` |
| 4 | Authorized Auth domains — add `localhost`, `127.0.0.1`, `stockmokweb.web.app`, `stockmokweb.firebaseapp.com`, and `stockmok.com` once DNS connects. **A missing entry breaks Google sign-in in production only** | Implementation | Stage 18 checklist |
| 5 | **ACR-003** — amend file `26` to remove the brand burn-in instruction. Non-database; blocks only future renderer-asset regeneration | Owner | before any regeneration |
| 6 | Re-run the three independent reviewers | Owner | when budget allows, before Codex starts |
| 7 | Measure the dashboard and product-list read counts against `NFR-017` | Implementation | Stage 17 |

None of these prevents Codex from starting the data foundation. Items 2 and 4 block *deployment*, not
*development*, and the emulator path is unaffected.

---

## 8. Gate result

```
UI_DATA_COVERAGE              = 100%
QUERY_COVERAGE                = 100%
INDEX_COVERAGE                = 100%
COMMAND_COVERAGE              = 100%
TRANSACTION_COVERAGE          = 100%
RBAC_COVERAGE                 = 100%
STATE_MACHINE_COVERAGE        = 100%
CANONICAL_SEED_RECONCILIATION = PASS
TENANT_ISOLATION              = PASS
CONNECTED_PRIVACY             = PASS
FIRESTORE_FEASIBILITY         = PASS
UNRESOLVED_BLOCKERS           = 0
```

**DATABASE_IMPLEMENTATION_READY = YES**

Qualified by one honest caveat carried in §1: `INDEPENDENT_REVIEWER_AVAILABLE = NO`. The required fresh
adversarial second pass was performed and found and fixed five defects, but a genuinely independent
review has not happened and should be run before Codex begins.
