# StockFlow Final UI QA and Completeness Matrix

**Status:** `PRE_GENERATION_QA = PASS`  
**Gate snapshot:** `INPUT_READ_CONFIRMATION = PASS`; `UI_ARCHITECTURE_FREEZE = PASS`; `PROMPT_QA = PASS`; `VISUAL_GENERATION_AND_QA = FAIL / BLOCKED_AT_B01`  
**Package decision:** `UI_DESIGN_PACKAGE_COMPLETE = NO`; `READY_FOR_HUMAN_REVIEW = NO`; `READY_FOR_PRODUCTION_CODING = NO`  
**Scope:** documentation and generated design visuals only; Release A and Release B-Lite only  
**Authority:** frozen files 00 and 18–28, with source precedence and test ranges defined in file 00

This matrix is the pre-generation control record. Independent prompt re-audit passed after remediation: all 106 structural prompt/visual/path records are approved for generation. A `PASS` below means the named documentation or prompt evidence reconciles; it does not imply PNG generation or visual approval. All visual, manifest, packaging, and final-approval rows remain `NOT_RUN`, `NOT_STARTED`, or `PENDING` until supported by physical-file and independent-review evidence.

## 1. QA vocabulary and immutable status enums

These enums are public artifact interfaces. Files 31–34 and the generated manifest must use them exactly.

### 1.1 Gate and check status

| Enum | Meaning |
|---|---|
| `PASS` | All required evidence exists and no unresolved defect remains for the check. |
| `FAIL` | Evidence proves at least one required criterion is incorrect, missing, conflicting, or out of scope. |
| `PENDING` | A required predecessor is incomplete; the check is not yet executable. |
| `NOT_RUN` | No execution or inspection evidence exists yet. |
| `NOT_APPLICABLE` | The item is explicitly outside Release A/B-Lite or is structurally irrelevant; a reason and destination are still required. |
| `BLOCKED` | Initial attempt and two permitted retries failed, or a hard stop prevents further in-scope progress. |

### 1.2 Defect severity and lifecycle

| Enum | Definition | Gate effect |
|---|---|---|
| `BLOCKER` | Source-integrity failure, unapproved prompt, missing required surface, scope/security leak, corrupt output, ID/path collision, or unrecoverable generation failure. | Stops the batch and final gate. |
| `CRITICAL` | Wrong organization/role/route/permission, private-data leak, invalid state transition, excluded-release leakage, or materially wrong canonical arithmetic. | Visual verdict `FAIL`; retry required. |
| `MAJOR` | Missing or incorrect required field, table column, action, status, unit, currency, chart alternative, responsive behavior, or unreadable core content. | Visual verdict `FAIL`; retry required. |
| `MINOR` | Non-functional polish issue that does not impair correctness, legibility, implementation fidelity, consistency, or accessibility cues. | May support `PASS_WITH_NOTES`; must be documented. |
| `NOTE` | Observation only; no requirement is violated. | No gate effect. |

Defect lifecycle is `OPEN`, `RETRY_PENDING`, `RESOLVED`, or `ACCEPTED_NOTE`. `WAIVED` is prohibited for a functional, scope, data, permission, technical, responsive, legibility, or accessibility defect.

### 1.3 Generation, QA, and approval enums

| Field | Allowed values |
|---|---|
| `PROMPT-STATUS` | `DRAFT`, `QA_FAILED`, `APPROVED_FOR_GENERATION`, `RETIRED` |
| `GENERATION-STATUS` | `NOT_STARTED`, `GENERATING`, `GENERATED`, `FAILED`, `BLOCKED`, `SUPERSEDED` |
| `TECHNICAL-QA` | `NOT_RUN`, `PASS`, `FAIL` |
| `VISUAL-QA` | `NOT_REVIEWED`, `PASS`, `PASS_WITH_NOTES`, `FAIL` |
| `FINAL-APPROVAL` | `PENDING`, `APPROVED`, `REJECTED`, `SUPERSEDED` |
| `BATCH-STATUS` | `NOT_STARTED`, `IN_PROGRESS`, `BATCH_QA_PASS`, `FAILED`, `BLOCKED` |

`PASS_WITH_NOTES` is permitted only for a documented `MINOR` or `NOTE`. It is prohibited for spelling, label, route, role, value, status, field, table, chart, crop, legibility, responsive, accessibility, scope, or technical-file defects.

## 2. Four-gate control matrix

| Gate | Entry evidence | Required pass condition | Current result | Downstream lock |
|---|---|---|---|---|
| `INPUT_READ_CONFIRMATION` | File 00 lists all canonical documents, coursework brief, supplied images, authority, purpose, inspection method, conflicts, and SHA-256 values. | 17/17 v3 documents read; brief read; 2/2 supplied PNGs inspected; 8/8 conflicts resolved; baseline hashes recorded. | `PASS` | Source mutation or hash mismatch stops all work. |
| `UI_ARCHITECTURE_FREEZE` | Files 18–25. | All frozen registry counts reconcile; routes, states, roles, actions, tables, forms, responsive classes, charts, components, brand family, and scope are decision-complete. | `PASS` | Prompt authoring may proceed; architecture IDs remain immutable. |
| `PROMPT_QA` | Files 26–27 plus independent prompt audit. | Exactly 106 unique prompt IDs, visual IDs, and output paths; every record self-contained and canonical-data-correct; zero unresolved prompt defects. | `PASS` | Opens `B01`; generation remains one approved prompt per call and subject to batch preflight. |
| `VISUAL_GENERATION_AND_QA` | Physical PNGs, files 31–33, generated manifest, independent original-detail review. | `P = I = 106`; 100% prompt/image traceability; every current image `PASS` or `PASS_WITH_NOTES`; zero failed, blocked, orphan, duplicate, rejected-as-current, superseded-as-current, or unreviewed items. | `FAIL` / `BLOCKED_AT_B01` | `VISUAL-BRAND-001` exhausted Retry 2 with exact-dimension failure; execution stops. |

## 3. Pre-generation source-integrity check

The 20 baseline authorities comprise v3 files 01–17, the v2 coursework brief, the v2 earlier showcase PNG, and the v3 improved showcase PNG.

| Check | Expected | Observed at this pre-generation checkpoint | Result |
|---|---:|---:|---|
| Canonical v3 authorities hashed | 17 | 17 | `PASS` |
| Auxiliary authorities hashed | 3 | 3 | `PASS` |
| Hashes equal file-00 baseline | 20 | 20 | `PASS` |
| Hash mismatches | 0 | 0 | `PASS` |
| Final post-execution rehash | 20 | not yet run | `PENDING` |

The final gate must recompute all 20 hashes. A mismatch fails the package even if every visual otherwise passes.

## 4. Frozen registry completeness

Counts below are derived from files 18–28, not estimates.

| Registry family | Frozen range / rule | Count | Completeness | Result |
|---|---|---:|---:|---|
| Canonical Release A aliases | `P0-01..P0-30` / `SCREEN-001..030` | 30 | 30/30 | `PASS` |
| Canonical Release B-Lite aliases | `P1-31..P1-40` / `SCREEN-031..040` | 10 | 10/10 | `PASS` |
| Derived distinct surfaces | `SCREEN-041..052` | 12 | 12/12 | `PASS` |
| All visual surfaces | `SCREEN-001..052` | 52 | 52/52 | `PASS` |
| Release allocation | A = 41; B-Lite = 11 | 52 | 52/52 | `PASS` |
| Roles | Owner, Admin, Inventory Manager, Procurement Manager, Storekeeper, Analyst, Viewer | 7 | 7/7 | `PASS` |
| Access values | `FULL`, `READ_ONLY`, `LIMITED`, `HIDDEN`, `DENIED` | 5 | 5/5 | `PASS` |
| Responsive classes | `R0`, `R1`, `R2` | 3 | 3/3 | `PASS` |
| Dedicated R2 surfaces | exact frozen set in §5 | 11 | 11/11 | `PASS` |
| Operational layouts | `LAYOUT-01..05`; no sixth layout | 5 | 5/5 | `PASS` |
| Routes | `ROUTE-001..036` | 36 | 36/36 | `PASS` |
| Instantiated links | 40 unique `LINK-###` records; unused ordinals remain unassigned | 40 | 40/40 | `PASS` |
| Actions | `ACTION-001..061` | 61 | 61/61 | `PASS` |
| Fields | `FIELD-001..060`, with `FIELD-024` retained as a retired tombstone | 60 IDs / 59 active | 60/60 | `PASS` |
| Forms | `FORM-001..023` | 23 | 23/23 | `PASS` |
| Tables | `TABLE-001..027` | 27 | 27/27 | `PASS` |
| States | `STATE-001..043` | 43 | 43/43 | `PASS` |
| Components | `COMP-001..025`; no 26th primitive | 25 | 25/25 | `PASS` |
| Charts | `CHART-001..003`; no fourth chart | 3 | 3/3 | `PASS` |
| Microcopy | `COPY-001..540` | 540 | 540/540 | `PASS` |

## 5. Surface, route, and responsive acceptance matrix

| Concern | Required evidence | Frozen destination | Pre-generation result | Visual result |
|---|---|---|---|---|
| Every primary surface | One inspectable desktop image for `SCREEN-001..052` | `PROMPT-SCREEN-001..052` | 52/52 prompts `PASS` | `NOT_RUN` |
| Canonical aliases preserved | 30 P0 and 10 P1 screen numbers remain aliases | Files 18–19 | 40/40 `PASS` | `NOT_RUN` |
| Dialog/panel routing | Adjustment, opening balance, discovery, publishing, invitation, confirmations, notification menu, and mobile nav remain hosted surfaces without invented routes | Files 19–20; screen prompts | `PASS` | `NOT_RUN` |
| Disabled Network | Network navigation/routes omitted; direct authenticated access renders `SCREEN-030` 404 | Files 18–20, 23, 26 | `PASS` | `NOT_RUN` |
| Report authorization | Stock on Hand all seven roles; PO report O/A/IM/PM/AN only; SK/VW denied; actions separately authorized | Files 19, 20, 23 | `PASS` | `NOT_RUN` |
| Dead links | Every sidebar, header, breadcrumb, tab, table, KPI, CTA, notification, and activity destination resolves or is deliberately non-link text | 36 routes + 40 link records in file 20 | `PASS` | `NOT_RUN` |
| R0 behavior | 1280 reference; 390/768 semantic reflow; no dedicated mobile artifact required | File 18 + prompts | `PASS` | `NOT_RUN` |
| R1 behavior | 1280 primary; explicit 768 behavior; table card/constrained-scroll alternative | Files 18, 19, 21, 26 | `PASS` | `NOT_RUN` |
| R2 behavior | Dedicated 1280 and 390 visuals; 44 px targets; no core horizontal scroll | §5.1 | `PASS` | `NOT_RUN` |

### 5.1 Exact R2 mapping

| Mobile prompt | Screen | Surface | Prompt evidence | Image evidence |
|---|---|---|---|---|
| `PROMPT-MOBILE-001` | `SCREEN-003` | Global Login | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-002` | `SCREEN-004` | Branded Business Login | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-003` | `SCREEN-006` | Workspace Selector | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-004` | `SCREEN-010` | Populated Dashboard | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-005` | `SCREEN-011` | Product List | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-006` | `SCREEN-013` | Product Detail | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-007` | `SCREEN-016` | Stock Adjustment sheet | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-008` | `SCREEN-023` | Purchase Order Detail | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-009` | `SCREEN-024` | Receiving | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-010` | `SCREEN-026` | Notifications | `PASS` | `NOT_RUN` |
| `PROMPT-MOBILE-011` | `SCREEN-043` | Mobile Application Navigation | `PASS` | `NOT_RUN` |

## 6. Role, state, workflow, and data QA

| Concern | Required check | Documentation result | Visual result |
|---|---|---|---|
| Seven-role coverage | Every screen and capability resolves for O/A/IM/PM/SK/AN/VW using the five access values. | `PASS` | `NOT_RUN` |
| Hard-matrix precedence | Inventory Manager and Analyst have no Network; Analyst has no audit/team/settings; Storekeeper cannot adjust; Viewer is limited; Admin cannot modify canonical Owner. | `PASS` | `NOT_RUN` |
| Hidden versus denied | Unauthorized UI actions hidden by default; disabled control only with explanatory tooltip; direct forbidden route denied. | `PASS` | `NOT_RUN` |
| Universal states | `STATE-001..008` assigned required/contextual/not-applicable per surface. | `PASS` | `NOT_RUN` |
| Branded-login states | `STATE-009..016` all represented distinctly. | `PASS` | `NOT_RUN` |
| Workflow states | `STATE-017..043` mapped to valid surfaces and transitions. | `PASS` | `NOT_RUN` |
| State machines | Invitation/membership, product/archive, connection, mapping, private PO, and connected PO transitions follow file 05. | `PASS` | `NOT_RUN` |
| Private versus Connected | Identity, badge, data shape, permissions, conversion, and history remain distinguishable; no private supplier data leaks. | `PASS` | `NOT_RUN` |
| Canonical quantity chain | `18 → 20 → 60 → 70 → 70 → 110 → 120 KG`. | `PASS` | `NOT_RUN` |
| Canonical value chain | `LKR 564,200.00 → 566,700.00 → 616,700.00 → 629,200.00 → 629,200.00 → 679,200.00 → 691,700.00`. | `PASS` | `NOT_RUN` |
| Connected conversion | `1 PACK = 5 KG`; `10 PACK = 50 KG`; supplier ship `200 → 190 PACK`; buyer remains 70 KG until receipt. | `PASS` | `NOT_RUN` |
| Superseded arithmetic | Isolated `18 → 58 → 68 KG` never appears as current design data. | `PASS` | `NOT_RUN` |
| Honest scope | No invented customers, testimonials, awards, prices, statistics, business proof, or production claims. | `PASS` | `NOT_RUN` |

## 7. Form, field, table, action, and chart reconciliation

| Registry | QA obligation | Current documentation evidence | Visual acceptance |
|---|---|---|---|
| 23 forms | Every form names visible/read-only fields, validation, submitting behavior, success outcome, and permission owner. | 23/23 `PASS` | Every owning image must show the applicable contract; `NOT_RUN`. |
| 60 field IDs | Every active field has exact label/type/help/validation; `FIELD-024` remains a non-rendered tombstone. | 60/60 `PASS` | No unlisted or retired editable field; `NOT_RUN`. |
| 27 tables | Exact columns, query, filters, indexed sort, 25-row cursor pagination, mobile fallback, empty/loading/error states. | 27/27 `PASS` | Columns and labels readable at original detail; `NOT_RUN`. |
| 61 actions | Exact label, role, precondition, state transition/destination, confirmation, and replay behavior. | 61/61 `PASS` | Only valid actions visible and legible; `NOT_RUN`. |
| 3 charts | Stock-status donut and inventory-by-location bar on dashboard; PO-status bar only on `SCREEN-049`; table/text alternatives adjacent. | 3/3 `PASS` | No fourth chart and no misplaced chart; `NOT_RUN`. |
| KPI classification | Inventory Value, Active SKU Count, Low Stock, Open POs, Awaiting Receipt remain KPI cards, not charts. | 5/5 `PASS` | `NOT_RUN`. |

## 8. Design-system and accessibility QA

| Criterion | Frozen requirement | Documentation result | Visual result |
|---|---|---|---|
| Direction | Light-first operational SaaS; one system sans family; Lucide-style icons. | `PASS` | `NOT_RUN` |
| Color | Primary blue `#1D4ED8`; restrained slate neutrals; semantic status uses text plus icon. | `PASS` | `NOT_RUN` |
| Tokens | 4-point spacing; documented type, radii, shadows, breakpoints, and focus ring. | `PASS` | `NOT_RUN` |
| Contrast | Normal text ≥ 4.5:1; large text ≥ 3:1; recorded text/status pairings meet WCAG AA. | `PASS` | `NOT_RUN` |
| Focus/keyboard | Visible two-layer focus; dialog trap/restore; logical keyboard order. | `PASS` | `NOT_RUN` |
| Mobile targets | Minimum 44×44 px and safe separation. | `PASS` | `NOT_RUN` |
| Components | Exactly `COMP-001..025`; all covered across 10 component boards. | 25/25 `PASS` | `NOT_RUN` |
| Exclusions | No dark theme, glass, gradients, decorative animation, global search, command palette, custom icon family, or 26th primitive. | `PASS` | `NOT_RUN` |

## 9. Complete v3 test-range traceability

All 197 test IDs from authoritative file 08 have a UI-design destination or an explicit out-of-scope/non-visual disposition. Implementation execution is not claimed by this design package.

| Test family | Complete range | Count | UI-design destination / disposition | Trace result |
|---|---|---:|---|---|
| Authentication | `T-AUTH-01..14` | 14 | Auth screens, branded states, invitation/reset flows | `PASS` |
| Organization/team/workspace | `T-ORG-01..12` | 12 | Onboarding, selector, Team, invitation states | `PASS` |
| CRUD | `T-CRUD-01..16` | 16 | Product/category/warehouse forms, lists, archive guards | `PASS` |
| Stock | `T-STOCK-01..15` | 15 | Opening balance, adjustment, movement, status/value states | `PASS` |
| Integrity | `T-INT-01..08` | 8 | Arithmetic, conversion, replay, precision, operation-state evidence | `PASS` |
| Partners | `T-PART-01..05` | 5 | Private partner screens and Private/Connected distinction | `PASS` |
| Private purchase orders | `T-PPO-01..14` | 14 | Builder, detail, receiving, snapshots and transitions | `PASS` |
| Security/RBAC | `T-SEC-01..23` | 23 | Hard role matrix, denied routes, tenant/private-data visibility | `PASS` |
| Network | `T-NET-01..16` | 16 | Connections, exact discovery, catalog, mapping and flag states | `PASS` |
| Connected purchase orders | `T-CPO-01..17` | 17 | Buyer/supplier projections, conversion, ship/receive states | `PASS` |
| Dashboard/reports | `T-REPORT-01..10` | 10 | KPIs, three charts, reports, deep links and alternatives | `PASS` |
| Notifications | `T-NOTIFY-01..05` | 5 | Notification center/menu, read/unread and actor visibility | `PASS` |
| Audit | `T-AUD-01..07` | 7 | Movement/timeline/history evidence; role-restricted views | `PASS` |
| UI/browser/accessibility | `T-UI-01..12` | 12 | Primary, mobile and state visuals; keyboard/focus design contract | `PASS` |
| Non-functional | `T-NFR-01..14` | 14 | Design-relevant pagination/responsive/accessibility/time/money constraints; build/deploy-only checks explicitly remain for implementation | `PASS` |
| Performance | `T-PERF-01..04` | 4 | Static design supports lazy charts and bounded density; measured runtime performance is implementation-only | `PASS` |
| Storefront | `T-SF-01..05` | 5 | Release D explicitly excluded; mapped to scope-leak prohibition, not to a screen | `NOT_APPLICABLE` |
| **Total** |  | **197** | **197/197 have a destination or explicit disposition** | **`PASS`** |

File 12's abbreviated historical ranges are not accepted as substitutes for these complete file-08 ranges.

## 10. Requirement and invariant destination matrix

| Authority family | Complete range | Design destination | Result |
|---|---|---|---|
| Authentication | `FR-AUTH-001..012` | `SCREEN-001..007`, `029..030`, `041`; auth prompts/states | `PASS` |
| Organization | `FR-ORG-001..013` | Onboarding, shell, workspace selector, Settings, disabled-Network behavior | `PASS` |
| Team | `FR-TEAM-001..011` | Team, invitation acceptance/link modal, hard Owner protection | `PASS` |
| Inventory | `FR-INV-001..014` | Product/category/warehouse screens, forms and tables | `PASS` |
| Stock | `FR-STOCK-001..017` | Detail Stock tab, opening balance, adjustment, movements, receiving | `PASS` |
| Partners | `FR-PART-001..007` | Suppliers, Buyers, Partner Detail, Private/Connected treatment | `PASS` |
| Private PO | `FR-PO-001..013` | PO list/builder/detail/private receiving | `PASS` |
| Network | `FR-NET-001..020` | B-Lite destinations; B-PLUS `FR-NET-003` and `FR-NET-017` explicitly excluded | `PASS` |
| Connected PO | `FR-CPO-001..017` | Connected buyer/supplier detail and connected receiving | `PASS` |
| Dashboard/reporting | `FR-DASH-001..009` | Dashboard variants, reports, KPIs and three charts | `PASS` |
| Notifications | `FR-NOTIFY-001..004` | Notification center/menu; B-PLUS `FR-NOTIFY-003` explicitly excluded | `PASS` |
| Audit | `FR-AUD-001..006` | Immutable movement/PO/connection history and authorized activity | `PASS` |
| Storefront | `FR-SF-001..005` | Release D exclusion audit only; no route, screen, prompt, or claim | `NOT_APPLICABLE` |
| Security | `SEC-001..020` | Screen/capability matrix, denied routes, safe projections | `PASS` |
| Non-functional | `NFR-001..020` | Responsive, accessibility, density, pagination, honesty and runtime-design constraints | `PASS` |
| Business rules | `BR-001..025` | Forms, state machines, confirmations, arithmetic and replay semantics | `PASS` |
| Invariants | `INV-01..21` | Cross-surface data visibility, conversion, snapshots and ledger evidence | `PASS` |

## 11. Prompt-set completeness, uniqueness, and approval

| Prompt family | Prompt range | Visual range | Required | Structurally present | Gate-approved now | Unique IDs/paths | Result |
|---|---|---|---:|---:|---:|---:|---|
| Primary screens | `PROMPT-SCREEN-001..052` | `VISUAL-SCREEN-001..052` | 52 | 52 | 52 | 52/52 | `PASS` |
| Mobile | `PROMPT-MOBILE-001..011` | `VISUAL-MOBILE-001..011` | 11 | 11 | 11 | 11/11 | `PASS` |
| State boards | `PROMPT-STATE-001..011` | `VISUAL-STATE-001..011` | 11 | 11 | 11 | 11/11 | `PASS` |
| Component boards | `PROMPT-COMP-001..010` | `VISUAL-COMP-001..010` | 10 | 10 | 10 | 10/10 | `PASS` |
| Brand boards | `PROMPT-BRAND-001..006` | `VISUAL-BRAND-001..006` | 6 | 6 | 6 | 6/6 | `PASS` |
| Showcase boards | `PROMPT-BOARD-001..008` | `VISUAL-BOARD-001..008` | 8 | 8 | 8 | 8/8 | `PASS` |
| Review/contact sheets | `PROMPT-REVIEW-001..008` | `VISUAL-REVIEW-001..008` | 8 | 8 | 8 | 8/8 | `PASS` |
| **Total** |  |  | **106** | **106** | **106** | **106/106 IDs and paths** | **`PASS`** |

All 106 records retain immutable IDs and exact paths and are independently approved for generation after re-audit of viewport, role/audience, route or host, shell, content, fields/columns, actions, state/status, canonical data, accessibility, responsive behavior, exclusions, and exact output path. Files 25 and 31 may reference prompt IDs but may not duplicate prompt bodies. File 32 must contain exactly one row per unique prompt.

## 12. Pre-generation defect and blocker summary

| Metric | Current value |
|---|---:|
| Documentation/prompt defects open | 0 |
| Documentation/prompt blockers open | 0 |
| Visual defects evaluated | 3 attempts for one visual ID |
| Visual defects open | 1 blocking technical defect |
| Failed visual attempts | 3 |
| Blocked visual IDs | 1 (`VISUAL-BRAND-001`) |
| Rejected current visuals | 0 |
| Superseded current visuals | 0 |

The three rejected attempts are preserved under `visual-designs/generated/24_rejected/`; no rejected image is registered as current.

## 13. Per-image technical and independent visual QA

Each of the 106 rows in files 31–33 and the generated manifest must satisfy every item below.

### 13.1 Technical file checks

| Check | Required evidence | Current status |
|---|---|---|
| Identity | Prompt ID, visual ID, batch, attempt and exact registered path agree. | `NOT_RUN` |
| Safe destination | Resolved path is inside `visual-designs/generated/` or `visual-designs/review-boards/`. | `NOT_RUN` |
| Collision | No overwrite; exactly one current file for the visual ID. | `NOT_RUN` |
| File format | Non-zero file; `.png`; valid eight-byte signature; full decode succeeds. | `NOT_RUN` |
| Dimensions | Actual width/height equal registered dimensions; aspect ratio matches. | `NOT_RUN` |
| Integrity | Source-generation and workspace-copy SHA-256 values match. | `NOT_RUN` |
| Registration | Byte size, mode, dimensions, ratio, hash, timestamp, tool and attempt recorded. | `NOT_RUN` |
| Original detail | Candidate opened at original detail before independent hand-off. | `NOT_RUN` |

### 13.2 Independent visual checks

| Dimension | Required pass evidence | Current status |
|---|---|---|
| Identity/context | Correct StockFlow mark, organization, role, route/host, breadcrumb, shell, navigation and flag state. | `NOT_RUN` |
| UI contract | Exact titles, labels, fields, columns, filters, sort, pagination, tabs, actions, statuses, units and currency. | `NOT_RUN` |
| Permissions/security | Hard RBAC, hidden/denied actions, report-tab rules, tenant isolation, no private-data leakage. | `NOT_RUN` |
| Workflow/state | Valid transitions, confirmations, immutable/final states, replay semantics and required decision data. | `NOT_RUN` |
| Canonical data | Full quantity/value chains and conversion/ship quantities reconcile. | `NOT_RUN` |
| Private/Connected | Distinction is unmistakable and projections show only allowed information. | `NOT_RUN` |
| Visual system | Frozen light-first system, blue/slate palette, spacing, radii, type and Lucide-style icons. | `NOT_RUN` |
| Charts/KPIs | Exactly three authorized charts with alternatives; five metrics remain KPIs. | `NOT_RUN` |
| Responsive/accessibility | Correct viewport, visible focus, status text+icon, 44 px targets, legibility and no core overflow. | `NOT_RUN` |
| Scope/honesty | A/B-Lite only; no excluded release, invented proof, storefront, marketplace, POS, sales, AI or forecasting. | `NOT_RUN` |

The independent reviewer must not be the visual's original author and must compare the current checksum against the exact approved prompt and files 18–29.

## 14. Retry, rejection, and supersession matrix

| Stage | Prompt/visual identity | Prompt handling | File handling | Status outcome |
|---|---|---|---|---|
| Initial attempt | Same immutable IDs; attempt `0` | Exact approved prompt | Candidate goes to current path only after collision preflight | `GENERATED` then independent QA |
| Initial failure | Same IDs | Record exact defect | Move to `24_rejected` with attempt/timestamp; never overwrite | `FAILED`, `VISUAL-QA=FAIL`, `FINAL-APPROVAL=REJECTED` |
| Retry 1 | Same IDs; regeneration count `1` | Approved body unchanged; append narrow defect-correction directive without changing UI | New candidate; rejected history retained | Re-run all technical and visual checks |
| Retry 2 | Same IDs; regeneration count `2` | ROOT may clarify ambiguity; preserve frozen UI and prior prompt revision; re-run prompt QA | New candidate; all history retained | Re-run all technical and visual checks |
| Three failed attempts | Same IDs | No new prompt or visual ID | Preserve all rejected evidence | `GENERATION-STATUS=BLOCKED`; batch and package fail |
| Replace a formerly approved visual | Same IDs | Only approved consistency correction | Move prior approved file to `25_superseded`; link both hashes | Prior `SUPERSEDED`; replacement returns to QA |

Rejected files never count as current. Superseded files never count as current. A current filename must begin with the exact `VISUAL-ID`.

## 15. Structural reconciliation and coverage formulas

Final checks are registry-derived:

```text
P = count(unique PROMPT-ID where PROMPT-STATUS = APPROVED_FOR_GENERATION and PROMPT_QA = PASS)
I = count(unique current generated files mapped one-to-one to those prompt IDs)
VISUAL_GENERATION_COVERAGE = I / P * 100
PROMPT_IMAGE_TRACEABILITY = fully reconciled current prompt/image rows / P * 100
```

Current pre-generation values:

| Metric | Formula result | Required final value | Status |
|---|---:|---:|---|
| Structurally registered prompt rows | 106 | 106 | `PASS` |
| `P` (gate-approved prompt IDs) | 106 | 106 | `PASS` |
| `I` | 0 | 106 | `FAIL` |
| Visual generation coverage | 0/106 = 0% | 100% | `FAIL` |
| Prompt/image traceability | 0/106 = 0% | 100% | `FAIL` |
| Independently reviewed current files | 0/106; three rejected attempts reviewed | 106/106 | `FAIL` |
| Current orphan files | 0 current files | 0 | `PASS` |
| Current duplicate mappings | 0 current files | 0 | `PASS` |

The final structural audit must also prove:

- every requirement, use case, entity, state, role, test, R2 screen, route, link, field, form, table, action, chart, component, prompt, visual and asset has one valid destination;
- prompt IDs, visual IDs, current filenames and current output paths are unique;
- every approved prompt has exactly one current generated file;
- every current generated file maps to exactly one approved prompt;
- no rejected or superseded file is registered as current;
- no current file is missing, orphaned, duplicate, blocked, failed or unreviewed;
- manifest, file 31, file 32, file 33 and the filesystem agree on path, dimensions, size, hash, attempt and verdict.

## 16. Final package gate

| Final criterion | Required | Current |
|---|---|---|
| Input/source hashes unchanged | 20/20 post-execution | `PASS` — 20/20 match |
| Architecture coverage | 100% | `PASS` |
| Prompt coverage | 106/106 independently approved | `PASS` |
| Generated current visuals | 106/106 | `FAIL` — 0/106 current |
| Prompt/image traceability | 100% | `FAIL` — 0% |
| Independent visual QA | 106/106 `PASS` or `PASS_WITH_NOTES` | `FAIL` — `VISUAL-BRAND-001` rejected |
| Visual QA failures | 0 | 1 blocked visual ID / 3 failed attempts |
| Total blocked | 0 | 1 |
| Unresolved UI blockers | 0 | 1 visual-generation blocker |
| Orphan/duplicate/missing current files | 0 | 106 missing current files; 0 orphan/duplicate current files |
| Rejected/superseded as current | 0 | `PENDING` |
| Manifest/file 31/file 32/file 33/filesystem reconciliation | 100% | `PENDING` |
| ZIP allowlist and exclusion audit | exact package contents only | `PENDING` |

The ZIP may contain only:

- `docs/ui-final/`
- `visual-designs/`
- `STOCKFLOW_UI_DESIGN_PACK_INDEX.md`

It must exclude application code, both input control packs, `node_modules`, caches, temporary files, secrets, rejected scratch locations outside the approved audit folders, and any unrelated workspace content.

## 17. Current decision

`PRE_GENERATION_QA = PASS` because source, architecture, registry, test-range, requirement, design-system, microcopy, prompt semantics, IDs and paths reconcile and independent prompt re-audit passed.

`VISUAL_GENERATION_AND_QA = FAIL / BLOCKED_AT_B01` because all three `VISUAL-BRAND-001` attempts decoded at 1483×1061 rather than the required 1536×1100; the retry budget is exhausted and independent original-detail QA confirmed rejection.

Therefore:

- `UI_DESIGN_PACKAGE_COMPLETE = NO`
- `READY_FOR_HUMAN_REVIEW = NO`
- `READY_FOR_PRODUCTION_CODING = NO`

These values may change only in file 34 after all 106 current visuals pass, the final source rehash and structural reconciliation pass, failed/blocker counts are zero, and the ZIP manifest matches the allowed package exactly. Production coding remains prohibited even after successful human-review readiness.
