# StockFlow Generated Visual Manifest

**Manifest status:** `PARTIAL / BLOCKED_AT_B01`  
**P:** 106  
**I:** 0  
**Current registered PNGs:** 0  
**Rejected evidence PNGs:** 3  
**Superseded PNGs:** 0

## Current-file manifest

No current file exists. `VISUAL-BRAND-001` is blocked and the remaining 105 assets are not started.

## Rejected evidence manifest

| Prompt ID | Visual ID | Attempt | Path | Dimensions | Bytes | SHA-256 | Verdict |
|---|---|---:|---|---:|---:|---|---|
| `PROMPT-BRAND-001` | `VISUAL-BRAND-001` | 0 | `visual-designs/generated/24_rejected/VISUAL-BRAND-001_attempt-0_20260810T103120Z_dimension-1483x1061.png` | 1483×1061 | 1,333,016 | `dadef8b9fe74ccd82bc49255586106c101e1a704c69a198ff2c6a1dbd20a3b4c` | `FAIL / REJECTED` |
| `PROMPT-BRAND-001` | `VISUAL-BRAND-001` | Retry 1 | `visual-designs/generated/24_rejected/VISUAL-BRAND-001_retry-1_20260810T103335Z_dimension-and-mark.png` | 1483×1061 | 1,270,397 | `fb62c5a9e7e6e6ca0383be02d022fece7287977670e8e559bb8be9e2e28fabab` | `FAIL / REJECTED` |
| `PROMPT-BRAND-001` | `VISUAL-BRAND-001` | Retry 2 | `visual-designs/generated/24_rejected/VISUAL-BRAND-001_retry-2_20260810T103545Z_dimension-1483x1061.png` | 1483×1061 | 1,343,405 | `83a1d6ec0732768101519f69356b22efc3c314d86b25f75e05472790d6fb7a90` | `FAIL / REJECTED` |

The canonical 106-row planned-asset interface remains file 31. No rejected path is a current output path.

