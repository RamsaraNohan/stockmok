# STOCKMOK - FINAL DESIGN ARTIFACT MANIFEST

Authority for identifying canonical final design files. Built 2026-08-15 from the live design-session artifacts and their session version history, the change register, the Gate-13 corrections, the Gate-14 references and the decision ledger - NOT from modification time. SHA-256 over full file bytes.

DESIGN_VERSION = v1.0 | DESIGN_PHASE = CLOSED | COMPONENT_COUNT = 25/25

## 1 - Canonical current set (10 logical artifacts)

| LOGICAL_ARTIFACT | CANONICAL_CURRENT_FILE | STATUS | SUPERSEDES | VERSION/HISTORY EVIDENCE | SHA-256 | REASON_CURRENT |
|---|---|---|---|---|---|---|
| Design System | Stockmok Design System.dc.html | CANONICAL | - | Session artifact; Gate 4 and Gate 13 patches applied in place (DEC-009, DEC-022) | 81e6fba3c0bd215008a74878104e0a0ede656c96cde6833c7eeb118ec2d63782 | Only copy; carries the 25/25 component set and frozen tokens |
| Gate 5 Public / Auth / Onboarding | Stockmok Gate 5 Public Auth Onboarding.dc.html | CANONICAL | - | DEC-010 auth contract; Gate 13 registry coverage PASS | 8a0ddc07dfccacbed8231ebbc8bd89c2b1118ca80f8ada282938865560c94ba5 | Only copy; no competing download |
| Gate 6 Dashboard / Inventory | Stockmok Gate 6 Dashboard Inventory.dc.html | CANONICAL | Gate 6 Dashboard Inventory new.dc.html (byte-identical) | Session artifact; DEC-023 | cb94a73cbf272600e198a4a57aa644b2cf382d3c5bbedbe266b14307ecf8f984 | The local new download is byte-identical, so DUPLICATE not rival version |
| Gate 7 Private Procurement | Stockmok Gate 7 Private Procurement.dc.html | CANONICAL | Gate 7 Private Procurement new.dc.html (f8a7c504af984b8a7315e0dfe086f9c0d57330ca9f0f135f8e70bd6630d7ee38) | Session artifact carrying the Gate-13 seven-item patch (DEC-022, DEC-023); the local download predates the patch | 776a02681dfb23ef171f52b5de99436eec5eafe46713045e542c6c8383365078 | Gate 13 corrections were applied to the session artifact, which is the state Gate 14 was drawn from and approved |
| Gate 8 Network Foundation | Stockmok Gate 8 Network Foundation.dc.html | CANONICAL | - | DEC-023 privacy / nine-item reconciliation | 9a953ffd796301d8d5c67586d8facd32184e9f145290889880d112d2ca1b103e | Only copy |
| Gate 9 Connected Workflows | Stockmok Gate 9 Connected Workflows.dc.html | CANONICAL | Gate 9 Connected Workflows new.dc.html (e10039879e1a63f16cdd9261e650516b5a1d221f98102af7ad2361472871044c) and Gate 9 Connected Workflows new.dc (1).html | Session artifact carrying the Gate-13 patch, incl. the connected-cancellation refusal restatement (DEC-022) | dcf064c4463dcdb786ce9a83b6b7c2165af8c3312f3fefef009afeed74f81eed | Same rule as Gate 7: the patched session artifact is the approved state |
| Gate 10 Supporting Operations | Stockmok Gate 10 Supporting Operations.dc.html | CANONICAL | - | DEC-023 | 7267ee2282059d9ea3dd546e1efa7e485e6c9a06ed6c76c5d4d8095264de0897 | Only copy |
| Gate 11 Responsive Reconciliation | Stockmok Gate 11 Responsive Reconciliation.dc.html | CANONICAL | - | DEC-023 RESPONSIVE_COVERAGE = PASS | 0f57134169ec1ba972aacc04a475250d995c9ce79e9a979fc6ab40c5f14e1f91 | Only copy |
| Gate 12 States + Accessibility | Stockmok Gate 12 States Accessibility.dc.html | CANONICAL | - | DEC-021 state grammar; DEC-023 DERIVED_STATE_COVERAGE = PASS | 1ab770af37deb4a406c55165d6cf1fd977ffaf24ddc605efe8dea9d23e6c8aca | Only copy |
| Gate 14 Owner Approval | Stockmok Gate 14 Owner Approval.dc.html | CANONICAL - APPROVED | - | DEC-024 presented; DEC-025 APPROVED 2026-08-15 | a1bbc21b143cfac0ba92ccef7372ef2f82a5270c4399f75fd92be1b3fa702892 | The approved package; the artifact the freeze attaches to |

Gate 13 was reconciliation/QA and produced no standalone visual artifact; its evidence is DEC-023, the seven-item patch entries in the change register, and the Gate 14 boards. GATE_13_VISUAL = NONE_EXISTED.

## 2 - Supporting canonical artifacts

| LOGICAL_ARTIFACT | CANONICAL_CURRENT_FILE | STATUS | SHA-256 |
|---|---|---|---|
| Brand refinement (Gate 1) | Stockmok Brand Refinement.dc.html | CANONICAL | 612226ee15836bfd8012845c17baff956dcaab8636d315f7c51fe82539205248 |
| Brand refinement, standalone viewer | Stockmok Brand Refinement Standalone.dc.html | CANONICAL_VARIANT | 5d7ecbdc8000f9a71f08ac09d7ffd78df1b393126703a8c4239f68293f33cf3d |
| Brand refinement, inlined single file | Stockmok Brand Refinement.html | DERIVED_EXPORT | 8f76c236c40abb9eccf9f4154ee836213b715ec2bc14a2fa6cecf6ce2f8c0172 |
| Gate 3 consolidated direction | Stockmok Gate 3 Consolidated.dc.html | HISTORICAL GATE (superseded as authority by Gates 4-14) | 02231028c237c15e706c595388ff8ed2cdacd0deaee24412afc884734906d748 |

## 3 - Historical exploration - NOT implementation authority

| FILE | STATUS | SHA-256 |
|---|---|---|
| Stockmok Gate 2 Territories.dc.html | EXPLORATION | a255c64e65bbd148d7183a9f979bd10527298a4969b69d4ba53631e8f9f49771 |
| Stockmok Gate 2 Territories 2nd.dc.html (local) | DUPLICATE, byte-identical | a255c64e65bbd148d7183a9f979bd10527298a4969b69d4ba53631e8f9f49771 |
| Stockmok Territory A.dc.html | EXPLORATION | b8474a613d12d05f494b083efaec7edc0cdb81dc01624ed04f4859fb5d2e0435 |
| Stockmok Territory B.dc.html | EXPLORATION | ef6d0638127600cef406d5c9313e62a523cc8d96f6ca04f592d146082cc60641 |
| Stockmok Territory C.dc.html | EXPLORATION | 8fe2b53aaa489b0ee80f0668d4b7c8cd62f1d71d354d32b20422f996dc2a85bd |

These boards informed DEC-006 and are retained as evidence. After the final Design System and Gates 5-14 they carry no independent authority.

## 4 - Duplicate / superseded classification (evidence preserved, contents unmodified)

| FILE in visual-designs/completed Stockmok Design programme/ | SHA-256 | CLASSIFICATION | DESTINATION |
|---|---|---|---|
| Stockmok Gate 2 Territories 2nd.dc.html | a255c64e65bbd148d7183a9f979bd10527298a4969b69d4ba53631e8f9f49771 | DUPLICATE | superseded/duplicate-downloads/ |
| Stockmok Gate 6 Dashboard Inventory new.dc.html | cb94a73cbf272600e198a4a57aa644b2cf382d3c5bbedbe266b14307ecf8f984 | DUPLICATE | superseded/duplicate-downloads/ |
| Stockmok Gate 7 Private Procurement new.dc.html | f8a7c504af984b8a7315e0dfe086f9c0d57330ca9f0f135f8e70bd6630d7ee38 | SUPERSEDED, pre-Gate-13-patch | superseded/replaced-gates/ |
| Stockmok Gate 9 Connected Workflows new.dc.html | e10039879e1a63f16cdd9261e650516b5a1d221f98102af7ad2361472871044c | SUPERSEDED, pre-Gate-13-patch | superseded/replaced-gates/ |
| Stockmok Gate 9 Connected Workflows new.dc (1).html | duplicate filename of the same download | DUPLICATE_DOWNLOAD | superseded/duplicate-downloads/ |
| Stockmok Gate 2 Territories.dc.html, Territory A/B/C | see section 3 | EXPLORATORY | superseded/exploratory/ |
| Stockmok Brand Refinement.html | 8f76c236c40abb9eccf9f4154ee836213b715ec2bc14a2fa6cecf6ce2f8c0172 | DERIVED_EXPORT | keep beside canonical |

Gate 7 and Gate 9 were the only two non-identical rival candidates, and they were resolved by authority order rather than timestamp: the Gate-13 seven-item patch (DEC-022, DEC-023) was applied to the session artifacts and the Gate-14 approval boards reference that patched state, so the local new downloads predate approval. UNRESOLVED_CLASSIFICATIONS = 0.

FINAL_FRONTEND_AUTHORITY_SET = UNAMBIGUOUS
